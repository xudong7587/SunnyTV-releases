#!/usr/bin/env python3
"""Replace FFmpeg shared libraries in a local Android APK and sign a new copy.

This tool does not create signing keys, change application IDs, install apps,
modify its inputs, or guarantee binary compatibility of modified libraries.
"""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

LIBRARIES = ("libavcodec.so", "libavutil.so", "libswresample.so", "libswscale.so")
ABI_INFO = {"armeabi-v7a": (1, 40), "arm64-v8a": (2, 183), "x86": (1, 3), "x86_64": (2, 62)}
SIGNATURE = re.compile(r"^META-INF/[^/]+\.(SF|RSA|DSA|EC)$", re.IGNORECASE)


def invoke(args: list[str]) -> str:
    try:
        return subprocess.run(args, check=True, text=True, capture_output=True).stdout
    except subprocess.CalledProcessError as exc:
        # Signer diagnostics can echo user-supplied paths; never print passwords.
        raise ValueError(f"Tool failed: {Path(args[0]).name} (exit {exc.returncode})") from exc


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def metadata(readelf: Path, path: Path, name: str, abi: str) -> set[str]:
    with path.open("rb") as stream:
        header = stream.read(64)
    if len(header) < 20 or header[:4] != b"\x7fELF" or header[5] != 1:
        raise ValueError(f"{name}: not a little-endian ELF shared library")
    elf_class, machine = ABI_INFO[abi]
    if header[4] != elf_class or struct.unpack_from("<H", header, 18)[0] != machine:
        raise ValueError(f"{name}: ELF architecture does not match {abi}")
    if struct.unpack_from("<H", header, 16)[0] != 3:
        raise ValueError(f"{name}: ELF is not ET_DYN")
    dynamic = invoke([str(readelf), "--dynamic", "--wide", str(path)])
    soname = re.findall(r"\(SONAME\).*?\[([^]]+)\]", dynamic)
    if soname != [name]:
        raise ValueError(f"{name}: SONAME must be {name}")
    needed = set(re.findall(r"\(NEEDED\).*?\[([^]]+)\]", dynamic))
    segments = invoke([str(readelf), "--program-headers", "--wide", str(path)])
    loads = [line.split() for line in segments.splitlines() if line.strip().startswith("LOAD ")]
    if not loads or any(int(parts[-1], 16) < 16384 or int(parts[-1], 16) % 16384
                        or (int(parts[1], 16) - int(parts[2], 16)) % 16384 for parts in loads):
        raise ValueError(f"{name}: PT_LOAD alignment must be a multiple of 16 KiB")
    return needed


def ffmpeg_symbols(readelf: Path, path: Path) -> tuple[set[tuple[str, str]], set[tuple[str, str]], set[str]]:
    """Read FFmpeg-related required and exported dynamic symbols, including versions."""
    required: set[tuple[str, str]] = set()
    exported: set[tuple[str, str]] = set()
    default_exports: set[str] = set()
    table = invoke([str(readelf), "--dyn-syms", "--wide", str(path)])
    for line in table.splitlines():
        fields = line.split()
        if len(fields) < 8 or not fields[0].endswith(":") or fields[4] not in {"GLOBAL", "WEAK"}:
            continue
        full = fields[7]
        symbol = full.split("@", 1)[0]
        if not symbol.startswith(("av", "swr_", "sws_")):
            continue
        version = full.split("@", 1)[1].lstrip("@") if "@" in full else ""
        if fields[6] == "UND":
            if fields[4] == "GLOBAL":
                required.add((symbol, version))
        else:
            exported.add((symbol, version))
            if "@" not in full or "@@" in full:
                default_exports.add(symbol)
    return required, exported, default_exports


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", type=Path, required=True, help="Original or unsigned relink APK; never modified")
    parser.add_argument("--abi", choices=ABI_INFO, required=True)
    parser.add_argument("--libs-dir", type=Path, required=True, help="Directory containing all four rebuilt .so files")
    parser.add_argument("--out", type=Path, required=True, help="New output APK; must not exist")
    parser.add_argument("--keystore", type=Path, required=True, help="Your own existing signing keystore")
    parser.add_argument("--key-alias", required=True)
    parser.add_argument("--store-pass-env", default="SUNNYTV_RELINK_STORE_PASS", help="Name of environment variable holding store password")
    parser.add_argument("--key-pass-env", help="Optional name of environment variable holding key password")
    parser.add_argument("--zipalign", type=Path, required=True)
    parser.add_argument("--apksigner", type=Path, required=True)
    parser.add_argument("--aapt", type=Path, required=True)
    parser.add_argument("--readelf", type=Path, required=True)
    parser.add_argument("--expected-input-sha256", help="Optional expected original APK SHA-256")
    args = parser.parse_args()

    source = args.apk.resolve(strict=True)
    out = args.out.absolute()
    if not out.parent.is_dir():
        raise ValueError("Output directory must already exist")
    if out.exists() or out.is_symlink() or out.resolve() == source:
        raise ValueError("Output must be a new file distinct from the input APK")
    if not args.keystore.is_file():
        raise ValueError("Your existing keystore does not exist")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", args.store_pass_env) or args.store_pass_env not in os.environ:
        raise ValueError("The named store-password environment variable must be set")
    if args.key_pass_env and (not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", args.key_pass_env) or args.key_pass_env not in os.environ):
        raise ValueError("The named key-password environment variable must be set")
    original_sha = sha256(source)
    if args.expected_input_sha256 and original_sha.lower() != args.expected_input_sha256.lower():
        raise ValueError("Input APK SHA-256 differs from the expected value")
    before = invoke([str(args.aapt), "dump", "badging", str(source)])
    identity = re.search(r"^package: name='([^']+)' versionCode='([0-9]+)' versionName='([^']+)'", before, re.MULTILINE)
    if not identity:
        raise ValueError("Could not read input APK identity")

    with tempfile.TemporaryDirectory(prefix="sunnytv-relink-", dir=out.parent) as temp:
        tmp = Path(temp)
        replacements = {}
        needed = set()
        for name in LIBRARIES:
            path = (args.libs_dir / name).resolve(strict=True)
            if not path.is_file():
                raise ValueError(f"{name}: replacement is not a regular file")
            # Validate and package the same local snapshot, even if the user's
            # build directory changes while the APK is being assembled.
            snapshot = tmp / ("replacement-" + name)
            with path.open("rb") as source_file, snapshot.open("xb") as saved:
                shutil.copyfileobj(source_file, saved, 1024 * 1024)
            needed |= metadata(args.readelf, snapshot, name, args.abi)
            replacements[f"lib/{args.abi}/{name}"] = snapshot

        unsigned = tmp / "unsigned.apk"
        with zipfile.ZipFile(source) as original, zipfile.ZipFile(unsigned, "x", allowZip64=True) as target:
            names = original.namelist()
            if len(names) != len(set(names)):
                raise ValueError("Input APK contains duplicate ZIP names")
            if not set(replacements).issubset(names):
                raise ValueError(f"Input APK does not contain all four libraries for {args.abi}")
            available = {Path(n).name for n in names if n.startswith(f"lib/{args.abi}/")}
            system = {"libc.so", "libm.so", "libdl.so", "liblog.so", "libandroid.so", "libz.so", "libjnigraphics.so", "libOpenSLES.so", "libEGL.so", "libGLESv2.so", "libmediandk.so", "libnativewindow.so"}
            if needed - available - system:
                raise ValueError("Replacement needs libraries not present in APK or the supported Android system set: " + ", ".join(sorted(needed - available - system)))
            required: set[tuple[str, str]] = set()
            exported: set[tuple[str, str]] = set()
            default_exports: set[str] = set()
            for path in replacements.values():
                req, exp, default = ffmpeg_symbols(args.readelf, path)
                required |= req
                exported |= exp
                default_exports |= default
            for name in ("libffmpegJNI.so", "libsunnyVideoJNI.so"):
                entry = f"lib/{args.abi}/{name}"
                if entry not in names:
                    raise ValueError(f"Input APK is missing {entry}")
                jni = tmp / name
                jni.write_bytes(original.read(entry))
                req, _, _ = ffmpeg_symbols(args.readelf, jni)
                required |= req
            missing = sorted((symbol, version) for symbol, version in required
                             if (version and (symbol, version) not in exported)
                             or (not version and symbol not in default_exports))
            if missing:
                raise ValueError("Replacement FFmpeg exports do not satisfy required symbols: " +
                                 ", ".join(name + ("@" + version if version else "") for name, version in missing[:12]))
            for item in original.infolist():
                if SIGNATURE.match(item.filename) or item.filename.upper() == "META-INF/MANIFEST.MF":
                    continue
                data = replacements[item.filename].read_bytes() if item.filename in replacements else original.read(item)
                target.writestr(item, data)

        aligned = tmp / "aligned.apk"
        signed = tmp / "signed.apk"
        invoke([str(args.zipalign), "-P", "16", "4", str(unsigned), str(aligned)])
        signer = [str(args.apksigner), "sign", "--ks", str(args.keystore), "--ks-key-alias", args.key_alias,
                  "--ks-pass", f"env:{args.store_pass_env}"]
        if args.key_pass_env:
            signer += ["--key-pass", f"env:{args.key_pass_env}"]
        invoke(signer + ["--out", str(signed), str(aligned)])
        invoke([str(args.apksigner), "verify", "--verbose", str(signed)])
        invoke([str(args.zipalign), "-c", "-P", "16", "4", str(signed)])
        after = invoke([str(args.aapt), "dump", "badging", str(signed)])
        output_identity = re.search(r"^package: name='([^']+)' versionCode='([0-9]+)' versionName='([^']+)'", after, re.MULTILINE)
        if not output_identity or output_identity.groups() != identity.groups():
            raise ValueError("APK identity changed unexpectedly")
        with zipfile.ZipFile(signed) as finished:
            for name, path in replacements.items():
                if hashlib.sha256(finished.read(name)).digest() != hashlib.sha256(path.read_bytes()).digest():
                    raise ValueError(f"Replacement readback mismatch: {name}")
        if sha256(source) != original_sha:
            raise ValueError("Input APK changed during processing")
        created = False
        try:
            with signed.open("rb") as stream:
                destination = out.open("xb")
                created = True
                with destination:
                    shutil.copyfileobj(stream, destination, 1024 * 1024)
                    destination.flush()
                    os.fsync(destination.fileno())
        except BaseException:
            # Only a partially written file created by this invocation may be removed.
            if created and out.is_file() and not out.is_symlink():
                out.unlink()
            raise
        if sha256(out) != sha256(signed):
            raise ValueError("Output APK readback did not match the signed temporary file")
    print(f"Application ID: {identity.group(1)}; version: {identity.group(3)} ({identity.group(2)})")
    print(f"Replaced ABI: {args.abi}; APK SHA-256: {sha256(out)}")
    print("Output signed with the supplied key. It cannot replace a differently signed installed app.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print(f"Cannot create relink APK: {exc}", file=sys.stderr)
        raise SystemExit(1)
