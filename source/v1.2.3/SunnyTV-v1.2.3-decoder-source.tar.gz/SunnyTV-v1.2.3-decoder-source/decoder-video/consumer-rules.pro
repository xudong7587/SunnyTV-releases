# JNI accesses the public Media3 output fields and methods below.
-keep class io.github.xudong7587.sunnytv.decoder.video.NativeVideoDecoder { *; }
-keep class io.github.xudong7587.sunnytv.decoder.video.VideoDecoderException { <init>(java.lang.String); }
-keepclassmembers class androidx.media3.decoder.VideoDecoderOutputBuffer { *; }
