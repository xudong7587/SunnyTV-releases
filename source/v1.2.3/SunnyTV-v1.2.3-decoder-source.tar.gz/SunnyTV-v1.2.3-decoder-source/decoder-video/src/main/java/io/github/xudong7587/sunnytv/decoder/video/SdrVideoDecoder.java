/* SPDX-License-Identifier: Apache-2.0 */
package io.github.xudong7587.sunnytv.decoder.video;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.Decoder;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;

/** Translates packet, frame and end-of-stream events to Media3's nonblocking decoder interface. */
@UnstableApi
final class SdrVideoDecoder
        implements Decoder<DecoderInputBuffer, VideoDecoderOutputBuffer, VideoDecoderException> {
    private static final int INPUT_COUNT = 4;
    private static final int OUTPUT_COUNT = 4;
    private static final long RELEASE_WAIT_MS = 150;

    private enum Stage { FREE, RECEIVING, PUBLISHED, RETIRED, RECLAIMING, RECLAIMED }
    private enum Drain { CANCELED, EMPTY, PROGRESSED, END }

    private final class OutputSlot {
        final VideoDecoderOutputBuffer buffer = new VideoDecoderOutputBuffer(ignored -> returnOutput(this));
        Stage stage = Stage.FREE;
        boolean heldByClient;
        boolean rendering;
        boolean ownsFrame;
    }

    // The monitor governs Java ownership only. No calls to the backend run while it is held.
    private final Object monitor = new Object();
    private final ArrayDeque<DecoderInputBuffer> freeInputs = new ArrayDeque<>(INPUT_COUNT);
    private final ArrayDeque<DecoderInputBuffer> pendingInputs = new ArrayDeque<>(INPUT_COUNT);
    private final ArrayDeque<OutputSlot> readyOutputs = new ArrayDeque<>(OUTPUT_COUNT);
    private final OutputSlot[] slots = new OutputSlot[OUTPUT_COUNT];
    private final Format format;
    private final VideoDecoderBackend backend;
    private final String name;
    private final Thread worker;

    @Nullable private DecoderInputBuffer clientInput;
    @Nullable private VideoDecoderException failure;
    private long generation;
    private long outputStartTimeUs = C.TIME_UNSET;
    private int skippedFrames;
    private int activeRenders;
    private boolean firstFrame = true;
    private boolean endPublished;
    private boolean released;

    SdrVideoDecoder(Format format, VideoDecoderBackend backend) {
        this.format = format;
        this.backend = backend;
        String codec = codecName(format.sampleMimeType);
        if (codec == null) {
            throw new IllegalArgumentException("Unsupported video codec");
        }
        name = "sunny.ffmpeg.video." + codec;
        for (int i = 0; i < INPUT_COUNT; i++) {
            freeInputs.addLast(new DecoderInputBuffer(DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_DIRECT));
        }
        for (int i = 0; i < OUTPUT_COUNT; i++) {
            slots[i] = new OutputSlot();
        }
        worker = new Thread(this::run, "SunnyTV software video decoder");
        worker.setDaemon(true);
        worker.start();
    }

    @Nullable
    static String codecName(@Nullable String mimeType) {
        if (MimeTypes.VIDEO_H264.equals(mimeType)) {
            return "h264";
        }
        if (MimeTypes.VIDEO_H265.equals(mimeType)) {
            return "hevc";
        }
        if (MimeTypes.VIDEO_MP4V.equals(mimeType)) {
            return "mpeg4";
        }
        return null;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setOutputStartTimeUs(long timeUs) {
        synchronized (monitor) {
            outputStartTimeUs = timeUs;
        }
    }

    @Override
    @Nullable
    public DecoderInputBuffer dequeueInputBuffer() throws VideoDecoderException {
        synchronized (monitor) {
            throwIfFailedLocked();
            if (released || clientInput != null) {
                return null;
            }
            clientInput = freeInputs.pollFirst();
            return clientInput;
        }
    }

    @Override
    public void queueInputBuffer(DecoderInputBuffer input) throws VideoDecoderException {
        synchronized (monitor) {
            throwIfFailedLocked();
            if (released || input == null || input != clientInput) {
                throw new IllegalStateException("Input buffer is not leased by this decoder");
            }
            clientInput = null;
            pendingInputs.addLast(input);
            monitor.notifyAll();
        }
    }

    @Override
    @Nullable
    public VideoDecoderOutputBuffer dequeueOutputBuffer() throws VideoDecoderException {
        synchronized (monitor) {
            throwIfFailedLocked();
            OutputSlot next = readyOutputs.pollFirst();
            if (next == null) {
                return null;
            }
            next.heldByClient = true;
            return next.buffer;
        }
    }

    @Override
    public void flush() {
        synchronized (monitor) {
            if (!released && failure == null) {
                generation++;
                skippedFrames = 0;
                firstFrame = true;
                endPublished = false;
                discardWorkLocked();
            }
        }
    }

    @Override
    public void release() {
        synchronized (monitor) {
            if (!released) {
                released = true;
                discardWorkLocked();
            }
        }

        // Most releases finish immediately. A native receive or a blocked Surface post may
        // finish later; the worker retains ownership and closes only after both have finished.
        if (Thread.currentThread() != worker) {
            try {
                worker.join(RELEASE_WAIT_MS);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
            }
        }
    }

    void render(VideoDecoderOutputBuffer output, Surface surface) throws VideoDecoderException {
        OutputSlot slot = null;
        for (OutputSlot candidate : slots) {
            if (candidate.buffer == output) {
                slot = candidate;
                break;
            }
        }
        if (slot == null) {
            throw new VideoDecoderException("视频帧不属于此解码器");
        }

        long frameGeneration;
        synchronized (monitor) {
            throwIfFailedLocked();
            if (released || slot.stage != Stage.PUBLISHED || !slot.heldByClient
                    || slot.rendering || !slot.ownsFrame) {
                return;
            }
            slot.rendering = true;
            activeRenders++;
            frameGeneration = generation;
        }

        try {
            backend.render(output, surface);
        } catch (VideoDecoderException | RuntimeException | Error problem) {
            VideoDecoderException error = asDecoderError(problem);
            synchronized (monitor) {
                if (!isCurrentLocked(frameGeneration)) {
                    return;
                }
                recordFailureLocked(error);
            }
            throw error;
        } finally {
            synchronized (monitor) {
                slot.rendering = false;
                activeRenders--;
                monitor.notifyAll();
            }
        }
    }

    private void run() {
        try {
            processWork();
        } catch (VideoDecoderException | InterruptedException | RuntimeException | Error problem) {
            synchronized (monitor) {
                recordFailureLocked(asDecoderError(problem));
            }
        } finally {
            finish();
        }
    }

    private void processWork() throws VideoDecoderException, InterruptedException {
        long backendGeneration = 0;
        while (true) {
            OutputSlot reclaim;
            DecoderInputBuffer packet = null;
            long workGeneration;
            synchronized (monitor) {
                if (released || failure != null) {
                    return;
                }
                reclaim = claimRetiredLocked();
                workGeneration = generation;
                if (reclaim == null) {
                    if (backendGeneration == workGeneration) {
                        packet = pendingInputs.pollFirst();
                    }
                    if (packet == null
                            && (backendGeneration == workGeneration || activeRenders != 0)) {
                        monitor.wait();
                        continue;
                    }
                }
            }

            if (reclaim != null) {
                reclaim(reclaim);
            } else if (packet == null) {
                backend.flush();
                backendGeneration = workGeneration;
            } else {
                try {
                    processPacket(packet, workGeneration);
                } catch (VideoDecoderException | RuntimeException | Error problem) {
                    synchronized (monitor) {
                        if (isCurrentLocked(workGeneration)) {
                            recordFailureLocked(asDecoderError(problem));
                        }
                    }
                } finally {
                    synchronized (monitor) {
                        recycleInputLocked(packet);
                    }
                }
            }
        }
    }

    private void processPacket(DecoderInputBuffer packet, long workGeneration)
            throws VideoDecoderException, InterruptedException {
        synchronized (monitor) {
            if (!isCurrentLocked(workGeneration) || endPublished) {
                return;
            }
        }

        if (packet.isEncrypted()) {
            throw new VideoDecoderException("视频软解码器不支持加密视频");
        }
        boolean eos = packet.isEndOfStream();
        ByteBuffer data = eos ? null : packet.data;
        int size = data == null ? 0 : data.remaining();
        if (!eos && size == 0) {
            throw new VideoDecoderException("视频软解码器收到空数据包");
        }

        while (true) {
            synchronized (monitor) {
                if (!isCurrentLocked(workGeneration)) {
                    return;
                }
            }
            int sent = backend.send(data, size, packet.timeUs, eos);
            if (sent != VideoDecoderBackend.AGAIN && sent != VideoDecoderBackend.FRAME
                    && sent != VideoDecoderBackend.END) {
                throw new VideoDecoderException("视频软解码器返回未知的输入状态");
            }
            if (sent == VideoDecoderBackend.END && !eos) {
                throw new VideoDecoderException("视频软解码器提前结束");
            }
            Drain drained = drainFrames(workGeneration);
            if (drained == Drain.CANCELED) {
                return;
            }
            if (drained == Drain.END) {
                if (!eos) {
                    throw new VideoDecoderException("视频软解码器提前结束");
                }
                publishEnd(packet.timeUs, workGeneration);
                return;
            }
            if (sent == VideoDecoderBackend.AGAIN && drained == Drain.PROGRESSED) {
                // The same input remains leased until FFmpeg accepts it.
                continue;
            }
            if (sent == VideoDecoderBackend.AGAIN || eos) {
                throw new VideoDecoderException("视频软解码器的输入和输出均无法继续");
            }
            return;
        }
    }

    private Drain drainFrames(long workGeneration) throws VideoDecoderException, InterruptedException {
        boolean receivedFrame = false;
        while (true) {
            OutputSlot slot = reserveOutput(workGeneration);
            if (slot == null) {
                return Drain.CANCELED;
            }
            try {
                int result = backend.receive(slot.buffer);
                if (result == VideoDecoderBackend.AGAIN) {
                    return receivedFrame ? Drain.PROGRESSED : Drain.EMPTY;
                }
                if (result == VideoDecoderBackend.END) {
                    return Drain.END;
                }
                if (result != VideoDecoderBackend.FRAME) {
                    throw new VideoDecoderException("视频软解码器返回未知的输出状态");
                }
                synchronized (monitor) {
                    slot.ownsFrame = true;
                    if (!isCurrentLocked(workGeneration)) {
                        return Drain.CANCELED;
                    }
                    if (slot.buffer.shouldBeSkipped || (outputStartTimeUs != C.TIME_UNSET
                            && slot.buffer.timeUs < outputStartTimeUs)) {
                        skippedFrames++;
                    } else {
                        slot.buffer.skippedOutputBufferCount = skippedFrames;
                        skippedFrames = 0;
                        if (firstFrame) {
                            slot.buffer.addFlag(C.BUFFER_FLAG_FIRST_SAMPLE);
                            firstFrame = false;
                        }
                        publishLocked(slot);
                    }
                }
                receivedFrame = true;
            } finally {
                retireUnpublished(slot);
            }
        }
    }

    private void publishEnd(long timeUs, long workGeneration) throws InterruptedException {
        OutputSlot slot = reserveOutput(workGeneration);
        if (slot == null) {
            return;
        }
        synchronized (monitor) {
            if (isCurrentLocked(workGeneration) && !endPublished) {
                slot.buffer.timeUs = timeUs;
                slot.buffer.addFlag(C.BUFFER_FLAG_END_OF_STREAM);
                publishLocked(slot);
                endPublished = true;
            }
        }
        retireUnpublished(slot);
    }

    @Nullable
    private OutputSlot reserveOutput(long workGeneration) throws InterruptedException {
        while (true) {
            OutputSlot reclaim;
            synchronized (monitor) {
                if (!isCurrentLocked(workGeneration)) {
                    return null;
                }
                reclaim = claimRetiredLocked();
                if (reclaim == null) {
                    for (OutputSlot slot : slots) {
                        if (slot.stage == Stage.FREE) {
                            slot.stage = Stage.RECEIVING;
                            slot.buffer.clear();
                            slot.buffer.skippedOutputBufferCount = 0;
                            slot.buffer.shouldBeSkipped = false;
                            slot.buffer.format = null;
                            return slot;
                        }
                    }
                    monitor.wait();
                    continue;
                }
            }
            reclaim(reclaim);
        }
    }

    private void publishLocked(OutputSlot slot) {
        slot.buffer.format = format;
        slot.stage = Stage.PUBLISHED;
        readyOutputs.addLast(slot);
    }

    private void retireUnpublished(OutputSlot slot) {
        synchronized (monitor) {
            if (slot.stage == Stage.RECEIVING) {
                slot.ownsFrame |= slot.buffer.decoderPrivate != 0;
                slot.stage = slot.ownsFrame ? Stage.RETIRED : Stage.FREE;
                monitor.notifyAll();
            }
        }
    }

    private void returnOutput(OutputSlot slot) {
        synchronized (monitor) {
            if (!slot.heldByClient) {
                return;
            }
            slot.heldByClient = false;
            if (slot.stage == Stage.PUBLISHED) {
                slot.stage = Stage.RETIRED;
            } else if (slot.stage == Stage.RECLAIMED) {
                slot.stage = Stage.FREE;
            }
            monitor.notifyAll();
        }
    }

    @Nullable
    private OutputSlot claimRetiredLocked() {
        for (OutputSlot slot : slots) {
            if (slot.stage == Stage.RETIRED && !slot.rendering) {
                slot.stage = Stage.RECLAIMING;
                return slot;
            }
        }
        return null;
    }

    private void reclaim(OutputSlot slot) {
        try {
            if (slot.ownsFrame) {
                backend.releaseOutput(slot.buffer);
            }
        } finally {
            synchronized (monitor) {
                slot.buffer.decoderPrivate = 0;
                slot.ownsFrame = false;
                // A flushed frame is already freed, but the caller still must return its buffer.
                slot.stage = slot.heldByClient ? Stage.RECLAIMED : Stage.FREE;
                monitor.notifyAll();
            }
        }
    }

    private void discardWorkLocked() {
        if (clientInput != null) {
            recycleInputLocked(clientInput);
            clientInput = null;
        }
        while (!pendingInputs.isEmpty()) {
            recycleInputLocked(pendingInputs.removeFirst());
        }
        readyOutputs.clear();
        for (OutputSlot slot : slots) {
            if (slot.stage == Stage.PUBLISHED) {
                slot.stage = Stage.RETIRED;
            }
        }
        monitor.notifyAll();
    }

    private void recycleInputLocked(DecoderInputBuffer input) {
        input.clear();
        input.format = null;
        freeInputs.addLast(input);
    }

    private boolean isCurrentLocked(long workGeneration) {
        return !released && failure == null && generation == workGeneration;
    }

    private void throwIfFailedLocked() throws VideoDecoderException {
        if (failure != null) {
            throw failure;
        }
    }

    private void recordFailureLocked(VideoDecoderException error) {
        if (!released && failure == null) {
            failure = error;
            discardWorkLocked();
        }
    }

    private static VideoDecoderException asDecoderError(Throwable problem) {
        if (problem instanceof VideoDecoderException) {
            return (VideoDecoderException) problem;
        }
        return new VideoDecoderException("视频软解码失败", problem);
    }

    private void finish() {
        boolean interrupted = false;
        try {
            while (true) {
                OutputSlot slot;
                synchronized (monitor) {
                    // Handles unexpected worker termination as well as explicit release.
                    discardWorkLocked();
                    slot = claimRetiredLocked();
                    if (slot == null) {
                        if (activeRenders == 0) {
                            freeInputs.clear();
                            break;
                        }
                        try {
                            monitor.wait();
                        } catch (InterruptedException problem) {
                            interrupted = true;
                        }
                        continue;
                    }
                }
                try {
                    reclaim(slot);
                } catch (RuntimeException | Error problem) {
                    synchronized (monitor) {
                        recordFailureLocked(asDecoderError(problem));
                    }
                }
            }
        } finally {
            try {
                backend.release();
            } catch (RuntimeException | Error problem) {
                synchronized (monitor) {
                    recordFailureLocked(asDecoderError(problem));
                }
            } finally {
                if (interrupted) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}
