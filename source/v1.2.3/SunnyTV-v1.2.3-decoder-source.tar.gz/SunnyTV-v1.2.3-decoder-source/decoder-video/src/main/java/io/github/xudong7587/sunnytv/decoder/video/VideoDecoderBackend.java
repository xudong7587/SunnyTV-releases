/* SPDX-License-Identifier: Apache-2.0 */
package io.github.xudong7587.sunnytv.decoder.video;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.nio.ByteBuffer;

/** Packet input and independently owned Surface frames for the software decoder. */
@UnstableApi
interface VideoDecoderBackend {
    int AGAIN = 0;
    int FRAME = 1;
    int END = 2;

    /** FRAME means accepted. AGAIN leaves the packet with the caller for retry after draining. */
    int send(@Nullable ByteBuffer data, int size, long timeUs, boolean eos)
            throws VideoDecoderException;

    /** FRAME transfers ownership of one decoded frame to the supplied output. */
    int receive(VideoDecoderOutputBuffer output) throws VideoDecoderException;

    void flush() throws VideoDecoderException;

    void render(VideoDecoderOutputBuffer output, Surface surface) throws VideoDecoderException;

    void releaseOutput(VideoDecoderOutputBuffer output);

    void release();
}
