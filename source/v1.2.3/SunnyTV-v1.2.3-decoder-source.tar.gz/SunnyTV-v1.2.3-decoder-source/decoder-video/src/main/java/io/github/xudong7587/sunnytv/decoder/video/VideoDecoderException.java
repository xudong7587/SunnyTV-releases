/* SPDX-License-Identifier: Apache-2.0 */
package io.github.xudong7587.sunnytv.decoder.video;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.DecoderException;

/** A software video decode or Surface output failure. */
@UnstableApi
public final class VideoDecoderException extends DecoderException {
    public VideoDecoderException(String message) {
        super(message);
    }

    public VideoDecoderException(String message, Throwable cause) {
        super(message, cause);
    }
}
