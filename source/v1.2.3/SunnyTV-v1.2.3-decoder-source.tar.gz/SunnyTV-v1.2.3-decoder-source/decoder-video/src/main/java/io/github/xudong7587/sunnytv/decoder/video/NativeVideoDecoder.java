/* SPDX-License-Identifier: Apache-2.0 */
package io.github.xudong7587.sunnytv.decoder.video;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.nio.ByteBuffer;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/** Owns an FFmpeg context and the native frames borrowed by Media3. */
@UnstableApi
final class NativeVideoDecoder implements VideoDecoderBackend {
    private static final int MAX_INITIALIZATION_BYTES = 1024 * 1024;

    private final ReentrantReadWriteLock lifetime = new ReentrantReadWriteLock(true);
    private final Object decode = new Object();
    private final Map<VideoDecoderOutputBuffer, Long> frames = new IdentityHashMap<>();
    private long context;

    NativeVideoDecoder(Format format) throws VideoDecoderException {
        String codec = SdrVideoDecoder.codecName(format.sampleMimeType);
        if (codec == null) {
            throw new VideoDecoderException("不支持的视频软解编码");
        }
        if (!VideoDecoderLibrary.isAvailable()) {
            throw new VideoDecoderException("视频软解码库无法加载：" + VideoDecoderLibrary.getLoadStatus());
        }

        byte[] initialization = flattenInitialization(format.initializationData);
        int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
        ColorInfo color = format.colorInfo;
        int colorSpace = color == null ? Format.NO_VALUE : color.colorSpace;
        int colorRange = color == null ? Format.NO_VALUE : color.colorRange;
        int rotation = format.rotationDegrees == Format.NO_VALUE ? 0 : format.rotationDegrees;

        try {
            context = nativeOpen(codec, initialization, threads, format.width, format.height,
                    colorSpace, colorRange, rotation);
        } catch (LinkageError problem) {
            throw new VideoDecoderException("视频软解码库缺少解码接口", problem);
        }
        if (context == 0) {
            throw new VideoDecoderException("无法初始化视频软解码器：" + codec);
        }
    }

    @Override
    public int send(@Nullable ByteBuffer data, int size, long timeUs, boolean eos)
            throws VideoDecoderException {
        ByteBuffer packet = null;
        if (eos) {
            if (size != 0) {
                throw new VideoDecoderException("视频结束标记不能携带数据");
            }
        } else {
            if (data == null || !data.isDirect() || size <= 0 || size > data.remaining()) {
                throw new VideoDecoderException("无效的视频软解输入缓冲区");
            }
            packet = data.slice();
            packet.limit(size);
        }

        synchronized (decode) {
            Lock read = lifetime.readLock();
            read.lock();
            try {
                return nativeSend(requireContext(), packet, size, timeUs, eos);
            } finally {
                read.unlock();
            }
        }
    }

    @Override
    public int receive(VideoDecoderOutputBuffer output) throws VideoDecoderException {
        synchronized (decode) {
            Lock read = lifetime.readLock();
            read.lock();
            try {
                long activeContext = requireContext();
                synchronized (output) {
                    if (output.decoderPrivate != 0 || frameFor(output) != null) {
                        throw new VideoDecoderException("上一个视频帧仍在使用");
                    }

                    boolean retained = false;
                    try {
                        int result = nativeReceive(activeContext, output);
                        long handle = output.decoderPrivate;
                        if (result == FRAME) {
                            if (handle == 0) {
                                throw new VideoDecoderException("视频软解未返回有效帧");
                            }
                            synchronized (frames) {
                                frames.put(output, handle);
                            }
                            retained = true;
                        }
                        return result;
                    } finally {
                        if (!retained && output.decoderPrivate != 0) {
                            long handle = output.decoderPrivate;
                            output.decoderPrivate = 0;
                            nativeReleaseFrame(handle);
                        }
                    }
                }
            } finally {
                read.unlock();
            }
        }
    }

    @Override
    public void render(VideoDecoderOutputBuffer output, Surface surface) throws VideoDecoderException {
        Lock read = lifetime.readLock();
        read.lock();
        try {
            long activeContext = requireContext();
            synchronized (output) {
                Long frame = frameFor(output);
                if (frame == null) {
                    throw new VideoDecoderException("视频帧已释放");
                }
                nativeRender(activeContext, frame, surface);
            }
        } finally {
            read.unlock();
        }
    }

    @Override
    public void flush() throws VideoDecoderException {
        Lock write = lifetime.writeLock();
        write.lock();
        try {
            nativeFlush(requireContext());
        } finally {
            write.unlock();
        }
    }

    @Override
    public void releaseOutput(VideoDecoderOutputBuffer output) {
        Lock read = lifetime.readLock();
        read.lock();
        try {
            synchronized (output) {
                Long handle;
                synchronized (frames) {
                    handle = frames.remove(output);
                }
                if (handle != null) {
                    output.decoderPrivate = 0;
                    nativeReleaseFrame(handle);
                }
            }
        } finally {
            read.unlock();
        }
    }

    @Override
    public void release() {
        Lock write = lifetime.writeLock();
        write.lock();
        try {
            long closing = context;
            if (closing == 0) {
                return;
            }
            context = 0;
            try {
                for (long frame : frames.values()) {
                    nativeReleaseFrame(frame);
                }
            } finally {
                for (VideoDecoderOutputBuffer output : frames.keySet()) {
                    output.decoderPrivate = 0;
                }
                frames.clear();
                nativeClose(closing);
            }
        } finally {
            write.unlock();
        }
    }

    @Nullable
    private Long frameFor(VideoDecoderOutputBuffer output) {
        synchronized (frames) {
            return frames.get(output);
        }
    }

    private long requireContext() throws VideoDecoderException {
        if (context == 0) {
            throw new VideoDecoderException("视频软解码器已关闭");
        }
        return context;
    }

    private static byte[] flattenInitialization(List<byte[]> blocks) throws VideoDecoderException {
        int size = 0;
        for (byte[] block : blocks) {
            if (block.length > MAX_INITIALIZATION_BYTES - size) {
                throw new VideoDecoderException("视频解码初始化数据超过 1 MiB");
            }
            size += block.length;
        }
        byte[] result = new byte[size];
        int offset = 0;
        for (byte[] block : blocks) {
            System.arraycopy(block, 0, result, offset, block.length);
            offset += block.length;
        }
        return result;
    }

    static native String nativeVersion();

    private static native long nativeOpen(String codec, byte[] initialization, int threads,
            int width, int height, int colorSpace, int colorRange, int rotation)
            throws VideoDecoderException;

    private static native int nativeSend(long context, @Nullable ByteBuffer packet, int size,
            long timeUs, boolean eos) throws VideoDecoderException;

    private static native int nativeReceive(long context, VideoDecoderOutputBuffer output)
            throws VideoDecoderException;

    private static native void nativeFlush(long context);

    private static native void nativeRender(long context, long frame, Surface surface)
            throws VideoDecoderException;

    private static native void nativeReleaseFrame(long frame);

    private static native void nativeClose(long context);
}
