/* SPDX-License-Identifier: Apache-2.0 */
package io.github.xudong7587.sunnytv.decoder.video;

import android.os.Handler;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.CryptoConfig;
import androidx.media3.decoder.Decoder;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import androidx.media3.exoplayer.RendererCapabilities;
import androidx.media3.exoplayer.video.DecoderVideoRenderer;
import androidx.media3.exoplayer.video.VideoRendererEventListener;

/** Connects SunnyTV's SDR software decoder to a Media3 video Surface. */
@UnstableApi
public final class ComponentVideoRenderer extends DecoderVideoRenderer {
    public static final String NAME = "SunnyFfmpegVideoRenderer";

    private static final int MAX_DIMENSION = 4096;
    private static final String ENCRYPTED_VIDEO = "加密视频";

    @Nullable private SdrVideoDecoder decoder;

    public ComponentVideoRenderer(
            long allowedJoiningTimeMs,
            @Nullable Handler eventHandler,
            @Nullable VideoRendererEventListener eventListener,
            int maxDroppedFramesToNotify) {
        super(allowedJoiningTimeMs, eventHandler, eventListener, maxDroppedFramesToNotify);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public int supportsFormat(Format format) {
        if (!MimeTypes.isVideo(format.sampleMimeType)) {
            return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_TYPE);
        }
        if (isEncrypted(format)) {
            return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_DRM);
        }
        if (!supportsInputFormat(format) || !VideoDecoderLibrary.isAvailable()) {
            return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_SUBTYPE);
        }
        return RendererCapabilities.create(C.FORMAT_HANDLED, ADAPTIVE_NOT_SEAMLESS, TUNNELING_NOT_SUPPORTED);
    }

    /** Checks declared stream properties without loading the native library. */
    public static boolean supportsInputFormat(Format format) {
        return unsupportedReason(format) == null;
    }

    /** Returns a fixed diagnostic message for a rejected format. */
    @Nullable
    public static String unsupportedReason(Format format) {
        if (isEncrypted(format)) {
            return ENCRYPTED_VIDEO;
        }

        String mimeType = format.sampleMimeType;
        if (MimeTypes.VIDEO_DOLBY_VISION.equals(mimeType)
                || MimeTypes.getCodecsCorrespondingToMimeType(
                        format.codecs, MimeTypes.VIDEO_DOLBY_VISION) != null) {
            return "Dolby Vision 视频";
        }
        if (!MimeTypes.VIDEO_H264.equals(mimeType)
                && !MimeTypes.VIDEO_H265.equals(mimeType)
                && !MimeTypes.VIDEO_MP4V.equals(mimeType)) {
            return "不支持的视频编码";
        }

        if (Math.max(format.width, format.decodedWidth) > MAX_DIMENSION
                || Math.max(format.height, format.decodedHeight) > MAX_DIMENSION) {
            return "视频尺寸超过 4096 像素";
        }
        if (format.rotationDegrees != 0 && format.rotationDegrees != Format.NO_VALUE) {
            return "视频带有旋转角度";
        }
        if (format.pixelWidthHeightRatio != 1.0f) {
            return "视频使用非方形像素";
        }

        ColorInfo color = format.colorInfo;
        if (color == null) {
            return null;
        }
        if (color.hdrStaticInfo != null || ColorInfo.isTransferHdr(color)) {
            return "HDR 视频";
        }
        if (!isEightBitOrUnknown(color.lumaBitdepth) || !isEightBitOrUnknown(color.chromaBitdepth)) {
            return "仅支持 8 位视频";
        }
        if (color.colorSpace != Format.NO_VALUE
                && color.colorSpace != C.COLOR_SPACE_BT601
                && color.colorSpace != C.COLOR_SPACE_BT709) {
            return "不支持的视频色彩空间";
        }
        if (color.colorTransfer != Format.NO_VALUE
                && color.colorTransfer != C.COLOR_TRANSFER_SDR
                && color.colorTransfer != C.COLOR_TRANSFER_SRGB
                && color.colorTransfer != C.COLOR_TRANSFER_GAMMA_2_2) {
            return "不支持的视频传递函数";
        }
        return null;
    }

    private static boolean isEncrypted(Format format) {
        return format.drmInitData != null || format.cryptoType != C.CRYPTO_TYPE_NONE;
    }

    private static boolean isEightBitOrUnknown(int bitDepth) {
        return bitDepth == 8 || bitDepth == Format.NO_VALUE;
    }

    @Override
    protected Decoder<DecoderInputBuffer, VideoDecoderOutputBuffer, VideoDecoderException>
            createDecoder(Format format, @Nullable CryptoConfig cryptoConfig)
                    throws VideoDecoderException {
        String reason = cryptoConfig == null ? unsupportedReason(format) : ENCRYPTED_VIDEO;
        if (reason != null) {
            throw new VideoDecoderException(reason);
        }
        NativeVideoDecoder backend = new NativeVideoDecoder(format);
        try {
            SdrVideoDecoder created = new SdrVideoDecoder(format, backend);
            decoder = created;
            return created;
        } catch (RuntimeException | Error failure) {
            backend.release();
            throw failure;
        }
    }

    @Override
    protected void renderOutputBufferToSurface(VideoDecoderOutputBuffer output, Surface surface)
            throws VideoDecoderException {
        try {
            SdrVideoDecoder active = decoder;
            if (active == null) {
                throw new VideoDecoderException("视频软解码器尚未初始化");
            }
            active.render(output, surface);
        } finally {
            output.release();
        }
    }

    @Override
    protected void setDecoderOutputMode(@C.VideoOutputMode int outputMode) {
        // The native decoder always produces Surface output buffers.
    }

    @Override
    protected void releaseDecoder() {
        try {
            super.releaseDecoder();
        } finally {
            decoder = null;
        }
    }
}
