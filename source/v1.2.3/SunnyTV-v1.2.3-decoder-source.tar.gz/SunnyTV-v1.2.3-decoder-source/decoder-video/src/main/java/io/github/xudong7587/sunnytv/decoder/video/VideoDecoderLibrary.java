/* SPDX-License-Identifier: Apache-2.0 */
package io.github.xudong7587.sunnytv.decoder.video;

import androidx.media3.common.util.UnstableApi;

/** Availability and version of the packaged SunnyTV video native library. */
@UnstableApi
public final class VideoDecoderLibrary {
    private VideoDecoderLibrary() {}

    private static final class LibraryState {
        private static final LibraryState LOADED = load();

        final String status;
        final String version;

        LibraryState(String status, String version) {
            this.status = status;
            this.version = version;
        }

        static LibraryState load() {
            try {
                System.loadLibrary("sunnyVideoJNI");
                String version = NativeVideoDecoder.nativeVersion();
                if (version != null && !version.isEmpty()) {
                    return new LibraryState("available", version);
                }
                return failure("native_linkage_error");
            } catch (UnsatisfiedLinkError failure) {
                return failure("native_link_error");
            } catch (LinkageError failure) {
                return failure("native_linkage_error");
            } catch (SecurityException failure) {
                return failure("native_load_blocked");
            }
        }

        static LibraryState failure(String status) {
            return new LibraryState(status, "unavailable");
        }
    }

    public static boolean isAvailable() {
        return "available".equals(getLoadStatus());
    }

    public static String getLoadStatus() {
        return LibraryState.LOADED.status;
    }

    public static String getVersion() {
        return LibraryState.LOADED.version;
    }
}
