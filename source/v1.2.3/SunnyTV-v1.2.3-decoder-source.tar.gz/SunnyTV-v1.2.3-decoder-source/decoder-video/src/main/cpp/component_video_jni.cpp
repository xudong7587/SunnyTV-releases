// SPDX-License-Identifier: Apache-2.0

#include <android/native_window_jni.h>
#include <jni.h>

#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <new>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavcodec/version.h>
#include <libavutil/avutil.h>
#include <libavutil/display.h>
#include <libavutil/error.h>
#include <libavutil/frame.h>
#include <libavutil/mem.h>
#include <libavutil/pixdesc.h>
#include <libswresample/swresample.h>
#include <libswresample/version.h>
#include <libswscale/swscale.h>
#include <libswscale/version.h>
}

namespace {

constexpr jint kAgain = 0;
constexpr jint kReady = 1;
constexpr jint kEnd = 2;
constexpr jint kMaxDimension = 4096;
constexpr jint kMaxInitializationBytes = 1024 * 1024;
constexpr jint kMaxPacketBytes = 32 * 1024 * 1024;
constexpr AVRational kMicrosecondTimeBase{1, 1000000};
constexpr jint kMedia3SurfaceYuv = 1;
constexpr jint kMedia3Bt601 = 2;
constexpr jint kMedia3FullRange = 1;

constexpr char kExceptionClass[] =
        "io/github/xudong7587/sunnytv/decoder/video/VideoDecoderException";
constexpr char kOutputClass[] = "androidx/media3/decoder/VideoDecoderOutputBuffer";

template <typename T, void (*Free)(T**)>
struct AvDeleter {
    void operator()(T* value) const { Free(&value); }
};

using Codec = std::unique_ptr<AVCodecContext, AvDeleter<AVCodecContext, avcodec_free_context>>;
using Packet = std::unique_ptr<AVPacket, AvDeleter<AVPacket, av_packet_free>>;
using Frame = std::unique_ptr<AVFrame, AvDeleter<AVFrame, av_frame_free>>;
using Scaler = std::unique_ptr<SwsContext, decltype(&sws_freeContext)>;
using Window = std::unique_ptr<ANativeWindow, decltype(&ANativeWindow_release)>;

struct OutputFields {
    jmethodID init = nullptr;
    jmethodID initPrivateFrame = nullptr;
    jfieldID frame = nullptr;

    bool resolve(JNIEnv* env) {
        jclass type = env->FindClass(kOutputClass);
        if (!type) return false;
        init = env->GetMethodID(type, "init", "(JILjava/nio/ByteBuffer;)V");
        if (init) initPrivateFrame = env->GetMethodID(type, "initForPrivateFrame", "(II)V");
        if (initPrivateFrame) frame = env->GetFieldID(type, "decoderPrivate", "J");
        env->DeleteLocalRef(type);
        return frame != nullptr;
    }
};

struct ColorConversion {
    AVPixelFormat format = AV_PIX_FMT_NONE;
    int width = 0;
    int height = 0;
    int matrix = SWS_CS_ITU709;
    int fullRange = 0;

    bool operator==(const ColorConversion& other) const {
        return format == other.format && width == other.width && height == other.height
                && matrix == other.matrix && fullRange == other.fullRange;
    }
};

struct RenderState {
    std::mutex lock;
    jobject surface = nullptr;
    Window window{nullptr, ANativeWindow_release};
    Scaler scaler{nullptr, sws_freeContext};
    ColorConversion conversion;

    void releaseSurface(JNIEnv* env) {
        window.reset();
        if (surface) {
            env->DeleteGlobalRef(surface);
            surface = nullptr;
        }
    }

    bool bindSurface(JNIEnv* env, jobject target) {
        if (surface && env->IsSameObject(surface, target)) return true;
        Window nextWindow{ANativeWindow_fromSurface(env, target), ANativeWindow_release};
        if (!nextWindow || env->ExceptionCheck()) return false;
        jobject nextSurface = env->NewGlobalRef(target);
        if (!nextSurface) return false;

        releaseSurface(env);
        surface = nextSurface;
        window = std::move(nextWindow);
        return true;
    }

    bool configureConversion(const ColorConversion& next) {
        if (scaler && next == conversion) return true;

        Scaler nextScaler{sws_getContext(next.width, next.height, next.format,
                next.width, next.height, AV_PIX_FMT_RGBA, SWS_BILINEAR,
                nullptr, nullptr, nullptr), sws_freeContext};
        if (!nextScaler) return false;

        const int* coefficients = sws_getCoefficients(next.matrix);
        constexpr int kUnity = 1 << 16;
        if (sws_setColorspaceDetails(nextScaler.get(), coefficients, next.fullRange,
                coefficients, 1, 0, kUnity, kUnity) < 0) {
            return false;
        }

        scaler = std::move(nextScaler);
        conversion = next;
        return true;
    }
};

struct Decoder {
    Decoder(jint colorSpace, jint colorRange) : colorSpace(colorSpace), colorRange(colorRange) {}

    Codec codec;
    Packet packet;
    Frame nextFrame;
    OutputFields output;
    const jint colorSpace;
    const jint colorRange;
    RenderState render;
};

template <typename T>
T* fromHandle(jlong handle) {
    return reinterpret_cast<T*>(static_cast<intptr_t>(handle));
}

template <typename T>
jlong toHandle(T* value) {
    return static_cast<jlong>(reinterpret_cast<intptr_t>(value));
}

void throwDecoder(JNIEnv* env, const char* message) {
    if (env->ExceptionCheck()) return;
    jclass type = env->FindClass(kExceptionClass);
    if (type) {
        env->ThrowNew(type, message);
        env->DeleteLocalRef(type);
    }
}

void throwFfmpeg(JNIEnv* env, const char* operation, int error) {
    char details[AV_ERROR_MAX_STRING_SIZE]{};
    av_strerror(error, details, sizeof(details));
    char message[192];
    std::snprintf(message, sizeof(message), "%s (%d): %s", operation, error, details);
    throwDecoder(env, message);
}

bool ffmpegAbiMatches() {
    return AV_VERSION_MAJOR(avcodec_version()) == LIBAVCODEC_VERSION_MAJOR
            && AV_VERSION_MAJOR(avutil_version()) == LIBAVUTIL_VERSION_MAJOR
            && AV_VERSION_MAJOR(swscale_version()) == LIBSWSCALE_VERSION_MAJOR
            && AV_VERSION_MAJOR(swresample_version()) == LIBSWRESAMPLE_VERSION_MAJOR;
}

AVCodecID codecId(JNIEnv* env, jstring name) {
    if (!name) return AV_CODEC_ID_NONE;
    const char* value = env->GetStringUTFChars(name, nullptr);
    if (!value) return AV_CODEC_ID_NONE;
    AVCodecID id = AV_CODEC_ID_NONE;
    if (std::strcmp(value, "h264") == 0) id = AV_CODEC_ID_H264;
    else if (std::strcmp(value, "hevc") == 0) id = AV_CODEC_ID_HEVC;
    else if (std::strcmp(value, "mpeg4") == 0) id = AV_CODEC_ID_MPEG4;
    env->ReleaseStringUTFChars(name, value);
    return id;
}

bool setInitialization(JNIEnv* env, AVCodecContext* codec, jbyteArray initialization) {
    if (!initialization) return true;
    const jsize bytes = env->GetArrayLength(initialization);
    if (bytes == 0) return true;
    if (bytes > kMaxInitializationBytes) {
        throwDecoder(env, "Video initialization data exceeds 1 MiB");
        return false;
    }
    codec->extradata = static_cast<uint8_t*>(av_mallocz(bytes + AV_INPUT_BUFFER_PADDING_SIZE));
    if (!codec->extradata) {
        throwDecoder(env, "Could not allocate video initialization data");
        return false;
    }
    codec->extradata_size = bytes;
    env->GetByteArrayRegion(initialization, 0, bytes, reinterpret_cast<jbyte*>(codec->extradata));
    return !env->ExceptionCheck();
}

jint codecResult(JNIEnv* env, int result, const char* operation) {
    if (result >= 0) return kReady;
    if (result == AVERROR(EAGAIN)) return kAgain;
    if (result == AVERROR_EOF) return kEnd;
    throwFfmpeg(env, operation, result);
    return kAgain;
}

bool supportedTransfer(AVColorTransferCharacteristic transfer) {
    switch (transfer) {
        case AVCOL_TRC_UNSPECIFIED:
        case AVCOL_TRC_BT709:
        case AVCOL_TRC_GAMMA22:
        case AVCOL_TRC_GAMMA28:
        case AVCOL_TRC_SMPTE170M:
        case AVCOL_TRC_IEC61966_2_1:
            return true;
        default:
            return false;
    }
}

bool hasHdrMetadata(const AVFrame* frame) {
    constexpr AVFrameSideDataType hdrTypes[] = {
            AV_FRAME_DATA_MASTERING_DISPLAY_METADATA,
            AV_FRAME_DATA_CONTENT_LIGHT_LEVEL,
            AV_FRAME_DATA_DOVI_RPU_BUFFER,
            AV_FRAME_DATA_DOVI_METADATA,
            AV_FRAME_DATA_DYNAMIC_HDR_PLUS,
            AV_FRAME_DATA_DYNAMIC_HDR_VIVID,
    };
    for (const auto type : hdrTypes) {
        if (av_frame_get_side_data(frame, type)) return true;
    }
    return false;
}

bool supportedColor(const AVFrame* frame) {
    const auto matrix = frame->colorspace;
    const auto primaries = frame->color_primaries;
    return (matrix == AVCOL_SPC_UNSPECIFIED || matrix == AVCOL_SPC_BT709
                    || matrix == AVCOL_SPC_BT470BG || matrix == AVCOL_SPC_SMPTE170M)
            && (primaries == AVCOL_PRI_UNSPECIFIED || primaries == AVCOL_PRI_BT709
                    || primaries == AVCOL_PRI_BT470BG || primaries == AVCOL_PRI_SMPTE170M)
            && supportedTransfer(frame->color_trc)
            && !hasHdrMetadata(frame);
}

bool supportedPixelFormat(AVPixelFormat format) {
    const AVPixFmtDescriptor* descriptor = av_pix_fmt_desc_get(format);
    if (!descriptor || descriptor->nb_components != 3
            || (descriptor->flags & (AV_PIX_FMT_FLAG_RGB | AV_PIX_FMT_FLAG_HWACCEL
                    | AV_PIX_FMT_FLAG_PAL | AV_PIX_FMT_FLAG_BAYER))
            || !sws_isSupportedInput(format)) {
        return false;
    }
    for (int i = 0; i < descriptor->nb_components; ++i) {
        if (descriptor->comp[i].depth != 8) return false;
    }
    return true;
}

bool isUnrotated(const AVFrame* frame) {
    const AVFrameSideData* sideData = av_frame_get_side_data(frame, AV_FRAME_DATA_DISPLAYMATRIX);
    if (!sideData) return true;
    int32_t matrix[9];
    if (sideData->size < sizeof(matrix)) return false;
    std::memcpy(matrix, sideData->data, sizeof(matrix));
    return av_display_rotation_get(matrix) == 0.0;
}

const char* unsupportedFrameReason(const AVFrame* frame) {
    if (frame->width <= 0 || frame->height <= 0
            || frame->width > kMaxDimension || frame->height > kMaxDimension) {
        return "Decoded video dimensions exceed the supported limit";
    }
    if (!supportedColor(frame) || !supportedPixelFormat(static_cast<AVPixelFormat>(frame->format))) {
        return "HDR or unsupported pixel format/color metadata is incompatible with 8-bit SDR video";
    }
    const AVRational aspect = frame->sample_aspect_ratio;
    if (aspect.num != 0 && (aspect.den <= 0 || aspect.num != aspect.den)) {
        return "Non-square video pixels are unsupported";
    }
    if (!isUnrotated(frame)) return "Rotated video frames are unsupported";
    return nullptr;
}

bool isJpegFormat(AVPixelFormat format) {
    switch (format) {
        case AV_PIX_FMT_YUVJ420P:
        case AV_PIX_FMT_YUVJ422P:
        case AV_PIX_FMT_YUVJ444P:
        case AV_PIX_FMT_YUVJ440P:
        case AV_PIX_FMT_YUVJ411P:
            return true;
        default:
            return false;
    }
}

ColorConversion conversionFor(const Decoder& decoder, const AVFrame* frame) {
    const auto format = static_cast<AVPixelFormat>(frame->format);
    const auto matrix = frame->colorspace;
    const bool bt601 = matrix == AVCOL_SPC_BT470BG || matrix == AVCOL_SPC_SMPTE170M
            || (matrix == AVCOL_SPC_UNSPECIFIED && decoder.colorSpace == kMedia3Bt601);
    const bool full = frame->color_range == AVCOL_RANGE_JPEG || isJpegFormat(format)
            || (frame->color_range == AVCOL_RANGE_UNSPECIFIED
                    && decoder.colorRange == kMedia3FullRange);
    return {format, frame->width, frame->height, bt601 ? SWS_CS_ITU601 : SWS_CS_ITU709, full};
}

bool configureWindow(ANativeWindow* window, const AVFrame* frame) {
    if (ANativeWindow_getWidth(window) == frame->width
            && ANativeWindow_getHeight(window) == frame->height
            && ANativeWindow_getFormat(window) == WINDOW_FORMAT_RGBA_8888) {
        return true;
    }
    return ANativeWindow_setBuffersGeometry(window, frame->width, frame->height,
            WINDOW_FORMAT_RGBA_8888) == 0;
}

bool validWindowBuffer(const ANativeWindow_Buffer& buffer, const AVFrame* frame) {
    return buffer.bits && buffer.format == WINDOW_FORMAT_RGBA_8888
            && buffer.width == frame->width && buffer.height == frame->height
            && buffer.stride >= frame->width && buffer.stride <= INT32_MAX / 4;
}

const char* renderFrame(RenderState& state, const AVFrame* frame) {
    ANativeWindow* window = state.window.get();
    if (!configureWindow(window, frame)) return "Could not configure the video Surface";

    ANativeWindow_Buffer buffer{};
    if (ANativeWindow_lock(window, &buffer, nullptr) != 0) {
        return "Could not lock the video Surface";
    }

    const bool valid = validWindowBuffer(buffer, frame);
    int rows = 0;
    if (valid) {
        uint8_t* destination[4] = {static_cast<uint8_t*>(buffer.bits)};
        int stride[4] = {buffer.stride * 4};
        rows = sws_scale(state.scaler.get(), frame->data, frame->linesize, 0,
                frame->height, destination, stride);
    }
    // The public window API releases a successful lock through unlockAndPost.
    const int postResult = ANativeWindow_unlockAndPost(window);
    if (!valid) return "Video Surface returned unexpected RGBA buffer geometry";
    if (rows != frame->height) return "Could not convert the full video frame to RGBA";
    if (postResult != 0) return "Could not post the video Surface buffer";
    return nullptr;
}

}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeVersion(
        JNIEnv* env, jclass) {
    return ffmpegAbiMatches() ? env->NewStringUTF(av_version_info()) : nullptr;
}

JNIEXPORT jlong JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeOpen(
        JNIEnv* env, jclass, jstring name, jbyteArray initialization, jint threads,
        jint width, jint height, jint colorSpace, jint colorRange, jint rotation) {
    if (!ffmpegAbiMatches()) {
        throwDecoder(env, "Incompatible video FFmpeg library versions");
        return 0;
    }
    if (width < -1 || height < -1 || width > kMaxDimension || height > kMaxDimension
            || rotation != 0) {
        throwDecoder(env, "Unsupported video dimensions or rotation");
        return 0;
    }

    const AVCodecID id = codecId(env, name);
    const AVCodec* implementation = id == AV_CODEC_ID_NONE ? nullptr : avcodec_find_decoder(id);
    if (!implementation) {
        throwDecoder(env, "Unsupported software video codec");
        return 0;
    }

    std::unique_ptr<Decoder> decoder{new (std::nothrow) Decoder(colorSpace, colorRange)};
    if (!decoder) {
        throwDecoder(env, "Could not allocate the video decoder");
        return 0;
    }
    decoder->codec.reset(avcodec_alloc_context3(implementation));
    decoder->packet.reset(av_packet_alloc());
    if (!decoder->codec || !decoder->packet) {
        throwDecoder(env, "Could not allocate the FFmpeg video decoder");
        return 0;
    }
    if (!decoder->output.resolve(env)) return 0;

    AVCodecContext* codec = decoder->codec.get();
    codec->width = std::max(0, width);
    codec->height = std::max(0, height);
    codec->max_pixels = kMaxDimension * kMaxDimension;
    codec->pkt_timebase = kMicrosecondTimeBase;
    codec->thread_count = std::clamp(threads, 1, 4);
    codec->thread_type = FF_THREAD_FRAME | FF_THREAD_SLICE;
    if (!setInitialization(env, codec, initialization)) return 0;

    const int result = avcodec_open2(codec, implementation, nullptr);
    if (result < 0) {
        throwFfmpeg(env, "Could not open the FFmpeg video decoder", result);
        return 0;
    }
    return toHandle(decoder.release());
}

JNIEXPORT jint JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeSend(
        JNIEnv* env, jclass, jlong handle, jobject buffer, jint size, jlong timeUs, jboolean eos) {
    auto* decoder = fromHandle<Decoder>(handle);
    if (!decoder) {
        throwDecoder(env, "Video decoder is closed");
        return kAgain;
    }
    if (eos) {
        if (size != 0) {
            throwDecoder(env, "Video end-of-stream packet must be empty");
            return kAgain;
        }
        return codecResult(env, avcodec_send_packet(decoder->codec.get(), nullptr),
                "Could not drain FFmpeg video packets");
    }
    if (!buffer || size <= 0 || size > kMaxPacketBytes
            || env->GetDirectBufferCapacity(buffer) < size) {
        throwDecoder(env, "Invalid direct video packet buffer or size");
        return kAgain;
    }
    const void* bytes = env->GetDirectBufferAddress(buffer);
    if (!bytes) {
        throwDecoder(env, "Could not access the direct video packet buffer");
        return kAgain;
    }

    AVPacket* packet = decoder->packet.get();
    const int allocation = av_new_packet(packet, size);
    if (allocation < 0) {
        throwFfmpeg(env, "Could not allocate the FFmpeg video packet", allocation);
        return kAgain;
    }
    std::memcpy(packet->data, bytes, size);
    packet->pts = timeUs;
    packet->dts = AV_NOPTS_VALUE;
    packet->time_base = kMicrosecondTimeBase;
    const int result = avcodec_send_packet(decoder->codec.get(), packet);
    av_packet_unref(packet);
    return codecResult(env, result, "Could not submit an FFmpeg video packet");
}

JNIEXPORT jint JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeReceive(
        JNIEnv* env, jclass, jlong handle, jobject output) {
    auto* decoder = fromHandle<Decoder>(handle);
    if (!decoder || !output || env->GetLongField(output, decoder->output.frame) != 0) {
        throwDecoder(env, "Video output buffer is unavailable");
        return kAgain;
    }

    if (!decoder->nextFrame) decoder->nextFrame.reset(av_frame_alloc());
    AVFrame* frame = decoder->nextFrame.get();
    if (!frame) {
        throwDecoder(env, "Could not allocate a decoded video frame");
        return kAgain;
    }
    const int result = avcodec_receive_frame(decoder->codec.get(), frame);
    if (result < 0) return codecResult(env, result, "Could not receive an FFmpeg video frame");

    const char* reason = unsupportedFrameReason(frame);
    const int64_t timestamp = frame->best_effort_timestamp != AV_NOPTS_VALUE
            ? frame->best_effort_timestamp : frame->pts;
    if (reason || timestamp == AV_NOPTS_VALUE) {
        av_frame_unref(frame);
        throwDecoder(env, reason ? reason : "Decoded video frame has no presentation timestamp");
        return kAgain;
    }

    env->CallVoidMethod(output, decoder->output.init, static_cast<jlong>(timestamp),
            kMedia3SurfaceYuv, static_cast<jobject>(nullptr));
    if (!env->ExceptionCheck()) {
        env->CallVoidMethod(output, decoder->output.initPrivateFrame, frame->width, frame->height);
    }
    if (env->ExceptionCheck()) {
        av_frame_unref(frame);
        return kAgain;
    }

    env->SetLongField(output, decoder->output.frame, toHandle(frame));
    decoder->nextFrame.release();
    return kReady;
}

JNIEXPORT void JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeFlush(
        JNIEnv*, jclass, jlong handle) {
    auto* decoder = fromHandle<Decoder>(handle);
    if (decoder) avcodec_flush_buffers(decoder->codec.get());
}

JNIEXPORT void JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeRender(
        JNIEnv* env, jclass, jlong decoderHandle, jlong frameHandle, jobject surface) {
    auto* decoder = fromHandle<Decoder>(decoderHandle);
    const auto* frame = fromHandle<AVFrame>(frameHandle);
    if (!decoder || !frame || !surface) {
        throwDecoder(env, "Video frame or Surface is unavailable");
        return;
    }

    RenderState& state = decoder->render;
    const std::lock_guard guard(state.lock);
    if (!state.configureConversion(conversionFor(*decoder, frame))) {
        throwDecoder(env, "Could not configure SDR video color conversion");
        return;
    }
    if (!state.bindSurface(env, surface)) {
        throwDecoder(env, "Could not acquire the video Surface");
        return;
    }
    if (const char* error = renderFrame(state, frame)) {
        state.releaseSurface(env);
        throwDecoder(env, error);
    }
}

JNIEXPORT void JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeReleaseFrame(
        JNIEnv*, jclass, jlong handle) {
    AVFrame* frame = fromHandle<AVFrame>(handle);
    av_frame_free(&frame);
}

JNIEXPORT void JNICALL Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeClose(
        JNIEnv* env, jclass, jlong handle) {
    std::unique_ptr<Decoder> decoder{fromHandle<Decoder>(handle)};
    if (decoder) decoder->render.releaseSurface(env);
}

}  // extern "C"
