# Provenance

Audio Java classes and JNI copied from androidx/media 1.9.4 at 75ccb55ec085d76cbbf12e2f1af8241d378a753a. Audited format routing, native loading, buffer allocation, decoding, reset and release. No network or filesystem playback access in these classes. Experimental video renderer excluded; its javadoc reference removed. CMake and FFmpeg build script retained. Gradle adapted to published 1.9.4 artifacts. Explicit UnstableApi opt-in added to the package-private decoder; package-wide NonNullApi removed for standalone compilation (explicit Nullable annotations retained).

The audio JNI now links the same hash-pinned FFmpeg n6.0.1 shared libraries as the video adapter; it no longer embeds a second FFmpeg build. The shared library's build configuration enables the previous AAC, AC3, E-AC3, DTS and TrueHD audio decoders as well as H.264, HEVC and MPEG-4 Part 2 video. Other audio decoders enabled in the shared binary may be exposed by Media3's existing format routing. See `decoder-video/UPSTREAM.md` and `VENDOR-MANIFEST.json` for provenance, licensing, exact boundaries and relink obligations. The old standalone static-library build script remains for historical workflows and is no longer an input to the application build.

The audio adapter reports the loaded FFmpeg library version via
`av_version_info()` so user-built libraries can be distinguished from the
unmodified runtime.
