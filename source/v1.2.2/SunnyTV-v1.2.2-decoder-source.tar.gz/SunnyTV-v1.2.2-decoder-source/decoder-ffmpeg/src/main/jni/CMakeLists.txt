#
# Copyright 2021 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# LINT.IfChange
cmake_minimum_required(VERSION 3.21.0 FATAL_ERROR)
# LINT.ThenChange(../../../build.gradle)

# Enable C++11 features.
set(CMAKE_CXX_STANDARD 11)

project(libffmpegJNI C CXX)

# Both renderers use the same pinned FFmpeg runtime from decoder-video. Keep
# the audio JNI as a separate adapter, but do not embed a second codec engine.
# The video module owns packaging these shared libraries. Link by name rather
# than declaring another set of IMPORTED runtime targets, so AGP packages each
# library only once when the application depends on both modules.
set(ffmpeg_vendor "${CMAKE_CURRENT_SOURCE_DIR}/../../../../decoder-video/src/main/cpp/vendor")
include_directories("${ffmpeg_vendor}/include")
find_library(android_log_lib log)

add_library(ffmpegJNI
            SHARED
            ffmpeg_jni.cc)
target_link_directories(ffmpegJNI PRIVATE "${ffmpeg_vendor}/lib/${ANDROID_ABI}")

target_link_libraries(ffmpegJNI
                      PRIVATE android
                      PRIVATE swresample
                      PRIVATE avcodec
                      PRIVATE avutil
                      PRIVATE ${android_log_lib})

# Enable 16 KB ELF alignment.
target_link_options(ffmpegJNI
                    PRIVATE "-Wl,-z,max-page-size=16384" "-Wl,--exclude-libs,ALL")
