cmake_minimum_required(VERSION 3.22.1)
project(sunnyVideoJNI LANGUAGES C CXX)
set(CMAKE_CXX_STANDARD 17)
foreach(ffmpeg_lib avcodec avutil swresample swscale)
    add_library(${ffmpeg_lib} SHARED IMPORTED)
    set_target_properties(${ffmpeg_lib} PROPERTIES IMPORTED_LOCATION
        "${CMAKE_CURRENT_SOURCE_DIR}/vendor/lib/${ANDROID_ABI}/lib${ffmpeg_lib}.so")
endforeach()
add_library(sunnyVideoJNI SHARED video_jni.cpp)
target_include_directories(sunnyVideoJNI PRIVATE vendor/include)
target_compile_options(sunnyVideoJNI PRIVATE -Wall -Wextra -Werror=return-type -fvisibility=hidden)
target_link_libraries(sunnyVideoJNI PRIVATE avcodec avutil swscale swresample android log)
target_link_options(sunnyVideoJNI PRIVATE
    "-Wl,-z,max-page-size=16384"
    "-Wl,--exclude-libs,ALL"
    "-Wl,--version-script=${CMAKE_CURRENT_SOURCE_DIR}/exports.map")
