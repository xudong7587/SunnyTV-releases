/*
 * SunnyTV native SDR video bridge. SPDX-License-Identifier: GPL-3.0-or-later
 * Packet/frame ownership and public ANativeWindow output independently implemented.
 * Protocol/API references: FFmpeg 6.0 public headers; audited NextLib sources listed in UPSTREAM.md.
 */
#include <jni.h>
#include <android/native_window_jni.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/display.h>
#include <libavutil/frame.h>
#include <libavutil/pixdesc.h>
#include <libswscale/swscale.h>
}

namespace {
constexpr int kAgain = 0, kFrame = 1, kEnd = 2;
constexpr int kMaxPacket = 32 * 1024 * 1024;
constexpr int kMaxDimension = 4096;
struct Context {
    AVCodecContext* codec = nullptr;
    SwsContext* scale = nullptr;
    ANativeWindow* window = nullptr;
    jobject surface = nullptr;
    int windowWidth = 0;
    int windowHeight = 0;
    int scaleWidth = 0;
    int scaleHeight = 0;
    int scaleFormat = -1;
    int scaleMatrix = -1;
    int scaleRange = -1;
    int fallbackMatrix = 1;
    int fallbackRange = 2;
    jmethodID outputInit = nullptr;
    jmethodID privateInit = nullptr;
    jfieldID privateField = nullptr;
};
struct FrameDeleter { void operator()(AVFrame* frame) const { av_frame_free(&frame); } };
struct PacketDeleter { void operator()(AVPacket* packet) const { av_packet_free(&packet); } };
using Frame = std::unique_ptr<AVFrame, FrameDeleter>;
using Packet = std::unique_ptr<AVPacket, PacketDeleter>;

void fail(JNIEnv* env, const char* message) {
    if (env->ExceptionCheck()) return;
    jclass type = env->FindClass("io/github/xudong7587/sunnytv/decoder/video/VideoDecoderException");
    if (type) { env->ThrowNew(type, message); env->DeleteLocalRef(type); }
}
void ffFail(JNIEnv* env, const char* action, int error) {
    char reason[AV_ERROR_MAX_STRING_SIZE], message[256];
    av_strerror(error, reason, sizeof(reason));
    std::snprintf(message, sizeof(message), "%s: %s", action, reason);
    fail(env, message);
}
void close(JNIEnv* env, Context* context) {
    if (!context) return;
    if (context->window) ANativeWindow_release(context->window);
    if (context->surface) env->DeleteGlobalRef(context->surface);
    sws_freeContext(context->scale);
    avcodec_free_context(&context->codec);
    delete context;
}

bool isSdrFrame(JNIEnv* env, const AVFrame* frame) {
    const AVPixFmtDescriptor* pixel = av_pix_fmt_desc_get(static_cast<AVPixelFormat>(frame->format));
    bool supported = pixel && !(pixel->flags & (AV_PIX_FMT_FLAG_HWACCEL | AV_PIX_FMT_FLAG_RGB));
    if (pixel) for (int i = 0; i < pixel->nb_components; i++) supported &= pixel->comp[i].depth == 8;
    supported &= frame->width > 0 && frame->height > 0
            && frame->width <= kMaxDimension && frame->height <= kMaxDimension;
    if (frame->sample_aspect_ratio.num > 0 && frame->sample_aspect_ratio.den > 0
            && frame->sample_aspect_ratio.num != frame->sample_aspect_ratio.den) supported = false;
    switch (frame->color_trc) {
        case AVCOL_TRC_UNSPECIFIED: case AVCOL_TRC_BT709: case AVCOL_TRC_GAMMA22:
        case AVCOL_TRC_GAMMA28: case AVCOL_TRC_SMPTE170M: case AVCOL_TRC_IEC61966_2_1: break;
        default: supported = false;
    }
    switch (frame->color_primaries) {
        case AVCOL_PRI_UNSPECIFIED: case AVCOL_PRI_BT709:
        case AVCOL_PRI_BT470BG: case AVCOL_PRI_SMPTE170M: break;
        default: supported = false;
    }
    switch (frame->colorspace) {
        case AVCOL_SPC_UNSPECIFIED: case AVCOL_SPC_BT709:
        case AVCOL_SPC_BT470BG: case AVCOL_SPC_SMPTE170M: break;
        default: supported = false;
    }
    supported &= !av_frame_get_side_data(frame, AV_FRAME_DATA_MASTERING_DISPLAY_METADATA)
            && !av_frame_get_side_data(frame, AV_FRAME_DATA_CONTENT_LIGHT_LEVEL)
            && !av_frame_get_side_data(frame, AV_FRAME_DATA_DOVI_RPU_BUFFER)
            && !av_frame_get_side_data(frame, AV_FRAME_DATA_DOVI_METADATA)
            && !av_frame_get_side_data(frame, AV_FRAME_DATA_DYNAMIC_HDR_PLUS)
            && !av_frame_get_side_data(frame, AV_FRAME_DATA_DYNAMIC_HDR_VIVID);
    if (const auto* rotation = av_frame_get_side_data(frame, AV_FRAME_DATA_DISPLAYMATRIX)) {
        if (rotation->size < 9 * sizeof(int32_t)) supported = false;
        else {
            double angle = av_display_rotation_get(reinterpret_cast<int32_t*>(rotation->data));
            supported &= std::isfinite(angle) && std::abs(angle) < 0.5;
        }
    }
    if (!supported) fail(env, "检测到HDR、广色域、非8位、旋转或非方形像素视频；补充软解仅支持方形像素8位SDR，请使用平台解码器");
    return supported;
}
} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeVersion(JNIEnv* env, jclass) {
    char version[80];
    std::snprintf(version, sizeof(version), "FFmpeg %s / libavcodec %u", av_version_info(), avcodec_version());
    return env->NewStringUTF(version);
}

extern "C" JNIEXPORT jlong JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeOpen(
        JNIEnv* env, jclass, jstring name, jbyteArray extra, jint threads, jint width, jint height,
        jint colorSpace, jint colorRange, jint rotation) {
    if (!name || !extra || rotation != 0 || width > kMaxDimension || height > kMaxDimension) {
        fail(env, "Unsupported software video parameters"); return 0;
    }
    if (AV_VERSION_MAJOR(avcodec_version()) != LIBAVCODEC_VERSION_MAJOR) {
        fail(env, "Video FFmpeg library version mismatch"); return 0;
    }
    const char* codecName = env->GetStringUTFChars(name, nullptr);
    if (!codecName) return 0;
    const AVCodec* codec = (std::strcmp(codecName, "h264") == 0 || std::strcmp(codecName, "hevc") == 0
            || std::strcmp(codecName, "mpeg4") == 0)
            ? avcodec_find_decoder_by_name(codecName) : nullptr;
    env->ReleaseStringUTFChars(name, codecName);
    if (!codec) { fail(env, "Requested video software decoder is unavailable"); return 0; }
    auto* context = new (std::nothrow) Context();
    if (!context) { fail(env, "Could not allocate video decoder"); return 0; }
    context->codec = avcodec_alloc_context3(codec);
    if (!context->codec) { close(env, context); fail(env, "Could not allocate video codec"); return 0; }
    int size = env->GetArrayLength(extra);
    if (size > 1024 * 1024) { close(env, context); fail(env, "Video extradata exceeds limit"); return 0; }
    if (size) {
        context->codec->extradata = static_cast<uint8_t*>(av_mallocz(size + AV_INPUT_BUFFER_PADDING_SIZE));
        if (!context->codec->extradata) { close(env, context); fail(env, "Could not allocate video extradata"); return 0; }
        context->codec->extradata_size = size;
        env->GetByteArrayRegion(extra, 0, size, reinterpret_cast<jbyte*>(context->codec->extradata));
        if (env->ExceptionCheck()) { close(env, context); return 0; }
    }
    context->fallbackMatrix = colorSpace == 2 ? SWS_CS_ITU601 : SWS_CS_ITU709;
    context->fallbackRange = colorRange;
    context->codec->thread_count = std::clamp(static_cast<int>(threads), 1, 4);
    context->codec->thread_type = FF_THREAD_FRAME | FF_THREAD_SLICE;
    context->codec->pkt_timebase = {1, 1000000};
    int result = avcodec_open2(context->codec, codec, nullptr);
    if (result < 0) { close(env, context); ffFail(env, "Could not open video codec", result); return 0; }
    jclass output = env->FindClass("androidx/media3/decoder/VideoDecoderOutputBuffer");
    if (!output) { close(env, context); return 0; }
    context->outputInit = env->GetMethodID(output, "init", "(JILjava/nio/ByteBuffer;)V");
    context->privateInit = env->GetMethodID(output, "initForPrivateFrame", "(II)V");
    context->privateField = env->GetFieldID(output, "decoderPrivate", "J");
    env->DeleteLocalRef(output);
    if (env->ExceptionCheck()) { close(env, context); return 0; }
    return reinterpret_cast<jlong>(context);
}

extern "C" JNIEXPORT jint JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeSend(
        JNIEnv* env, jclass, jlong pointer, jobject data, jint size, jlong pts, jboolean end) {
    auto* context = reinterpret_cast<Context*>(pointer);
    if (end) {
        int result = avcodec_send_packet(context->codec, nullptr);
        if (result == AVERROR(EAGAIN)) return kAgain;
        if (result < 0 && result != AVERROR_EOF) ffFail(env, "Could not drain video codec", result);
        return kFrame;
    }
    if (!data || size <= 0 || size > kMaxPacket || env->GetDirectBufferCapacity(data) < size) {
        fail(env, "Invalid or oversized compressed video packet"); return kAgain;
    }
    const auto* source = static_cast<const uint8_t*>(env->GetDirectBufferAddress(data));
    if (!source) { fail(env, "Video input must use a direct buffer"); return kAgain; }
    Packet packet(av_packet_alloc());
    if (!packet) { fail(env, "Could not allocate video packet"); return kAgain; }
    int result = av_new_packet(packet.get(), size);
    if (result < 0) { ffFail(env, "Could not allocate video packet data", result); return kAgain; }
    std::memcpy(packet->data, source, size);
    packet->pts = pts;
    packet->dts = AV_NOPTS_VALUE;
    result = avcodec_send_packet(context->codec, packet.get());
    if (result == AVERROR(EAGAIN)) return kAgain;
    if (result < 0) { ffFail(env, "Video packet rejected", result); return kAgain; }
    return kFrame;
}

extern "C" JNIEXPORT jint JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeReceive(
        JNIEnv* env, jclass, jlong pointer, jobject output) {
    auto* context = reinterpret_cast<Context*>(pointer);
    Frame frame(av_frame_alloc());
    if (!frame) { fail(env, "Could not allocate decoded video frame"); return kAgain; }
    int result = avcodec_receive_frame(context->codec, frame.get());
    if (result == AVERROR(EAGAIN)) return kAgain;
    if (result == AVERROR_EOF) return kEnd;
    if (result < 0) { ffFail(env, "Video frame decoding failed", result); return kAgain; }
    if (!isSdrFrame(env, frame.get())) return kAgain;
    int64_t pts = frame->best_effort_timestamp;
    if (pts == AV_NOPTS_VALUE) pts = frame->pts;
    if (pts == AV_NOPTS_VALUE) { fail(env, "Decoded video frame has no timestamp"); return kAgain; }
    env->CallVoidMethod(output, context->outputInit, static_cast<jlong>(pts), 1, nullptr);
    env->CallVoidMethod(output, context->privateInit, frame->width, frame->height);
    if (env->ExceptionCheck()) return kAgain;
    env->SetLongField(output, context->privateField, reinterpret_cast<jlong>(frame.release()));
    return kFrame;
}

extern "C" JNIEXPORT void JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeFlush(JNIEnv*, jclass, jlong pointer) {
    avcodec_flush_buffers(reinterpret_cast<Context*>(pointer)->codec);
}

extern "C" JNIEXPORT void JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeRender(
        JNIEnv* env, jclass, jlong pointer, jlong framePointer, jobject surface) {
    auto* context = reinterpret_cast<Context*>(pointer);
    auto* frame = reinterpret_cast<AVFrame*>(framePointer);
    if (!surface || !frame || !isSdrFrame(env, frame)) return;
    if (!context->window || !env->IsSameObject(context->surface, surface)) {
        jobject replacementSurface = env->NewGlobalRef(surface);
        if (!replacementSurface) { fail(env, "Could not acquire native video surface"); return; }
        ANativeWindow* replacementWindow = ANativeWindow_fromSurface(env, surface);
        if (!replacementWindow) {
            env->DeleteGlobalRef(replacementSurface);
            fail(env, "Could not acquire native video surface"); return;
        }
        if (context->window) ANativeWindow_release(context->window);
        if (context->surface) env->DeleteGlobalRef(context->surface);
        context->surface = replacementSurface;
        context->window = replacementWindow;
        context->windowWidth = context->windowHeight = 0;
    }
    if (context->windowWidth != frame->width || context->windowHeight != frame->height
            || ANativeWindow_getWidth(context->window) != frame->width
            || ANativeWindow_getHeight(context->window) != frame->height
            || ANativeWindow_getFormat(context->window) != WINDOW_FORMAT_RGBA_8888) {
        if (ANativeWindow_setBuffersGeometry(context->window, frame->width, frame->height, WINDOW_FORMAT_RGBA_8888)) {
            fail(env, "Video surface does not support software RGBA output"); return;
        }
        context->windowWidth = frame->width;
        context->windowHeight = frame->height;
    }
    if (!context->scale || context->scaleWidth != frame->width || context->scaleHeight != frame->height
            || context->scaleFormat != frame->format) {
        context->scale = sws_getCachedContext(context->scale, frame->width, frame->height,
                static_cast<AVPixelFormat>(frame->format), frame->width, frame->height, AV_PIX_FMT_RGBA,
                SWS_BILINEAR, nullptr, nullptr, nullptr);
        if (!context->scale) { fail(env, "Could not initialize SDR video color conversion"); return; }
        context->scaleWidth = frame->width;
        context->scaleHeight = frame->height;
        context->scaleFormat = frame->format;
        // A replacement swscale context has default color settings, even with identical metadata.
        context->scaleMatrix = context->scaleRange = -1;
    }
    int matrix = context->fallbackMatrix;
    if (frame->colorspace == AVCOL_SPC_BT709) matrix = SWS_CS_ITU709;
    else if (frame->colorspace == AVCOL_SPC_SMPTE170M || frame->colorspace == AVCOL_SPC_BT470BG)
        matrix = SWS_CS_ITU601;
    bool fullRange = frame->color_range == AVCOL_RANGE_JPEG
            || frame->format == AV_PIX_FMT_YUVJ420P || frame->format == AV_PIX_FMT_YUVJ422P
            || frame->format == AV_PIX_FMT_YUVJ444P || frame->format == AV_PIX_FMT_YUVJ440P
            || (frame->color_range == AVCOL_RANGE_UNSPECIFIED && context->fallbackRange == 1);
    if (context->scaleMatrix != matrix || context->scaleRange != static_cast<int>(fullRange)) {
        const int* coefficients = sws_getCoefficients(matrix);
        if (sws_setColorspaceDetails(context->scale, coefficients, fullRange, coefficients, 1, 0, 1 << 16, 1 << 16) < 0) {
            fail(env, "Could not configure SDR matrix and range"); return;
        }
        context->scaleMatrix = matrix;
        context->scaleRange = fullRange;
    }
    ANativeWindow_Buffer buffer{};
    if (ANativeWindow_lock(context->window, &buffer, nullptr)) {
        fail(env, "Could not lock native video surface"); return;
    }
    bool valid = buffer.bits && buffer.format == WINDOW_FORMAT_RGBA_8888
            && buffer.width >= frame->width && buffer.height >= frame->height && buffer.stride >= frame->width;
    int converted = -1;
    if (valid) {
        uint8_t* planes[4] = {static_cast<uint8_t*>(buffer.bits), nullptr, nullptr, nullptr};
        int strides[4] = {buffer.stride * 4, 0, 0, 0};
        converted = sws_scale(context->scale, frame->data, frame->linesize, 0, frame->height, planes, strides);
    }
    int posted = ANativeWindow_unlockAndPost(context->window);
    if (!valid || converted != frame->height || posted) fail(env, "Could not present decoded SDR video frame");
}

extern "C" JNIEXPORT void JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeReleaseFrame(JNIEnv*, jclass, jlong pointer) {
    auto* frame = reinterpret_cast<AVFrame*>(pointer);
    av_frame_free(&frame);
}
extern "C" JNIEXPORT void JNICALL
Java_io_github_xudong7587_sunnytv_decoder_video_NativeVideoDecoder_nativeClose(JNIEnv* env, jclass, jlong pointer) {
    close(env, reinterpret_cast<Context*>(pointer));
}
