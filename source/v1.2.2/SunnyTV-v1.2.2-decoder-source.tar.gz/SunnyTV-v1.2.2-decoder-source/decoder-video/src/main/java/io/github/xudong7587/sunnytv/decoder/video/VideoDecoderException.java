/* SPDX-License-Identifier: GPL-3.0-or-later */
package io.github.xudong7587.sunnytv.decoder.video;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.DecoderException;

@UnstableApi
public final class VideoDecoderException extends DecoderException {
    public VideoDecoderException(String message) { super(message); }
    public VideoDecoderException(String message, Throwable cause) { super(message, cause); }
}
