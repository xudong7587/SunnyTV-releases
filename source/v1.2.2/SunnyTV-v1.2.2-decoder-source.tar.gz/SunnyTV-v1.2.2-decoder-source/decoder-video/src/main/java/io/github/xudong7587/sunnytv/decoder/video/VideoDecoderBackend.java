/* SPDX-License-Identifier: GPL-3.0-or-later */
package io.github.xudong7587.sunnytv.decoder.video;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.nio.ByteBuffer;

@UnstableApi
interface VideoDecoderBackend {
    int AGAIN = 0, FRAME = 1, END = 2;
    int send(@Nullable ByteBuffer data, int size, long timeUs, boolean end) throws VideoDecoderException;
    int receive(VideoDecoderOutputBuffer output) throws VideoDecoderException;
    void flush() throws VideoDecoderException;
    void render(VideoDecoderOutputBuffer output, Surface surface) throws VideoDecoderException;
    void releaseOutput(VideoDecoderOutputBuffer output);
    void release();
}
