/* SPDX-License-Identifier: GPL-3.0-or-later */
package io.github.xudong7587.sunnytv.decoder.video;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.nio.ByteBuffer;
import java.util.List;

@UnstableApi
final class NativeVideoDecoder implements VideoDecoderBackend {
    // The codec worker and the renderer touch disjoint native state. Keep them independent so
    // that expensive SDR conversion / Surface posting can overlap decoding the next packet.
    // flush() and release() take both locks (in this order) for reset and shared-context cleanup.
    private final Object codecLock = new Object();
    private final Object renderLock = new Object();
    private long context;

    NativeVideoDecoder(Format format) throws VideoDecoderException {
        if (!VideoDecoderLibrary.isAvailable()) throw new VideoDecoderException("补充视频软解库未能加载");
        String codec;
        if (MimeTypes.VIDEO_H264.equals(format.sampleMimeType)) codec = "h264";
        else if (MimeTypes.VIDEO_H265.equals(format.sampleMimeType)) codec = "hevc";
        else if (MimeTypes.VIDEO_MP4V.equals(format.sampleMimeType)) codec = "mpeg4";
        else throw new VideoDecoderException("Unsupported software video codec");
        List<byte[]> init = format.initializationData;
        int total = 0;
        for (byte[] value : init) {
            if (value.length > 1_048_576 - total) throw new VideoDecoderException("Video initialization data is too large");
            total += value.length;
        }
        byte[] extra = new byte[total];
        int offset = 0;
        for (byte[] value : init) { System.arraycopy(value, 0, extra, offset, value.length); offset += value.length; }
        int colorSpace = format.colorInfo == null ? Format.NO_VALUE : format.colorInfo.colorSpace;
        int colorRange = format.colorInfo == null ? Format.NO_VALUE : format.colorInfo.colorRange;
        context = nativeOpen(codec, extra, Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors())),
                format.width, format.height, colorSpace, colorRange,
                format.rotationDegrees == Format.NO_VALUE ? 0 : format.rotationDegrees);
        if (context == 0) throw new VideoDecoderException("Could not initialize the video software decoder");
    }

    @Override public int send(@Nullable ByteBuffer data, int size, long timeUs, boolean end)
            throws VideoDecoderException {
        synchronized (codecLock) {
            requireOpen();
            return nativeSend(context, data == null ? null : data.slice(), size, timeUs, end);
        }
    }
    @Override public int receive(VideoDecoderOutputBuffer output) throws VideoDecoderException {
        synchronized (codecLock) { requireOpen(); return nativeReceive(context, output); }
    }
    @Override public void flush() throws VideoDecoderException {
        // Do not reset the codec while an old frame is still being posted to the Surface.
        // The same fixed lock order as release() avoids a seek/release lock inversion.
        synchronized (codecLock) { synchronized (renderLock) {
            requireOpen(); nativeFlush(context);
        } }
    }
    @Override public void render(VideoDecoderOutputBuffer output, Surface surface) throws VideoDecoderException {
        synchronized (renderLock) {
            requireOpen();
            if (output.decoderPrivate == 0) throw new VideoDecoderException("Video frame has already been released");
            nativeRender(context, output.decoderPrivate, surface);
        }
    }
    @Override public void releaseOutput(VideoDecoderOutputBuffer output) {
        synchronized (renderLock) {
            if (output.decoderPrivate != 0) { nativeReleaseFrame(output.decoderPrivate); output.decoderPrivate = 0; }
        }
    }
    @Override public void release() {
        synchronized (codecLock) { synchronized (renderLock) {
            if (context != 0) { nativeClose(context); context = 0; }
        } }
    }
    private void requireOpen() throws VideoDecoderException {
        if (context == 0) throw new VideoDecoderException("Video decoder has been released");
    }
    static native String nativeVersion();
    private static native long nativeOpen(String codec, byte[] extra, int threads, int width, int height,
            int colorSpace, int colorRange, int rotation) throws VideoDecoderException;
    private static native int nativeSend(long context, @Nullable ByteBuffer data, int size, long timeUs,
            boolean end) throws VideoDecoderException;
    private static native int nativeReceive(long context, VideoDecoderOutputBuffer output) throws VideoDecoderException;
    private static native void nativeFlush(long context);
    private static native void nativeRender(long context, long frame, Surface surface) throws VideoDecoderException;
    private static native void nativeReleaseFrame(long frame);
    private static native void nativeClose(long context);
}
