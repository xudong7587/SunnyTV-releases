/* SPDX-License-Identifier: GPL-3.0-or-later */
package io.github.xudong7587.sunnytv.decoder.video;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.Decoder;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Bounded worker decoder: one compressed packet may yield zero, one or several reordered frames. */
@UnstableApi
final class SdrVideoDecoder implements Decoder<DecoderInputBuffer, VideoDecoderOutputBuffer, VideoDecoderException> {
    private final Object lock = new Object();
    private final ArrayDeque<DecoderInputBuffer> freeInputs = new ArrayDeque<>(), queuedInputs = new ArrayDeque<>();
    private final ArrayDeque<VideoDecoderOutputBuffer> freeOutputs = new ArrayDeque<>(), queuedOutputs = new ArrayDeque<>();
    private final List<VideoDecoderOutputBuffer> allOutputs = new ArrayList<>();
    private final VideoDecoderBackend backend;
    private final Format format;
    private final Thread worker;
    @Nullable private DecoderInputBuffer borrowedInput;
    @Nullable private VideoDecoderException error;
    private boolean released;
    private long generation;
    private long outputStartUs = C.TIME_UNSET;

    SdrVideoDecoder(Format format, VideoDecoderBackend backend) {
        this.format = format;
        this.backend = backend;
        for (int i = 0; i < 4; i++) {
            freeInputs.add(new DecoderInputBuffer(DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_DIRECT, 64));
            VideoDecoderOutputBuffer output = new VideoDecoderOutputBuffer(this::recycleOutput);
            freeOutputs.add(output);
            allOutputs.add(output);
        }
        worker = new Thread(this::run, "SunnyVideoDecoder");
        worker.setDaemon(true);
        worker.start();
    }

    @Override public String getName() { return "sunny.ffmpeg.video." +
            (MimeTypes.VIDEO_H264.equals(format.sampleMimeType) ? "h264" :
                MimeTypes.VIDEO_H265.equals(format.sampleMimeType) ? "hevc" : "mpeg4"); }
    @Override public void setOutputStartTimeUs(long timeUs) { synchronized (lock) { outputStartUs = timeUs; } }
    @Override @Nullable public DecoderInputBuffer dequeueInputBuffer() throws VideoDecoderException {
        synchronized (lock) {
            checkError();
            if (released) return null;
            if (borrowedInput != null) throw new IllegalStateException("An input buffer is already dequeued");
            borrowedInput = freeInputs.pollFirst();
            return borrowedInput;
        }
    }
    @Override public void queueInputBuffer(DecoderInputBuffer input) throws VideoDecoderException {
        synchronized (lock) {
            checkError();
            if (released || input != borrowedInput) throw new IllegalStateException("Input ownership changed");
            queuedInputs.add(input);
            borrowedInput = null;
            lock.notifyAll();
        }
    }
    @Override @Nullable public VideoDecoderOutputBuffer dequeueOutputBuffer() throws VideoDecoderException {
        synchronized (lock) { checkError(); return queuedOutputs.pollFirst(); }
    }
    @Override public void flush() {
        synchronized (lock) {
            generation++;
            outputStartUs = C.TIME_UNSET;
            if (borrowedInput != null) { recycleInput(borrowedInput); borrowedInput = null; }
            while (!queuedInputs.isEmpty()) recycleInput(queuedInputs.removeFirst());
            while (!queuedOutputs.isEmpty()) queuedOutputs.removeFirst().release();
            lock.notifyAll();
        }
    }
    @Override public void release() {
        synchronized (lock) { released = true; lock.notifyAll(); }
        worker.interrupt();
        // Cleanup belongs to the worker, even if malformed input makes a native call slow.
        // Never free a context still being decoded. Surface replacement belongs to the player.
        try { worker.join(2000); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
    }
    void render(VideoDecoderOutputBuffer output, Surface surface) throws VideoDecoderException { backend.render(output, surface); }

    private void checkError() throws VideoDecoderException { if (error != null) throw error; }
    private void recycleInput(DecoderInputBuffer input) { input.clear(); freeInputs.add(input); }
    private void recycleOutput(VideoDecoderOutputBuffer output) {
        backend.releaseOutput(output);
        synchronized (lock) {
            output.clear();
            if (!released) freeOutputs.add(output);
            lock.notifyAll();
        }
    }

    private void run() {
        long activeGeneration = 0;
        boolean receive = false, draining = false, ended = false, blocked = false, first = true;
        int skipped = 0;
        DecoderInputBuffer pending = null;
        try {
            while (true) {
                VideoDecoderOutputBuffer output = null;
                boolean reset;
                long cycle;
                synchronized (lock) {
                    while (!released && generation == activeGeneration
                            && (freeOutputs.isEmpty() || (!receive && (ended || (pending == null && queuedInputs.isEmpty())))))
                        lock.wait();
                    if (released) return;
                    cycle = generation;
                    reset = cycle != activeGeneration;
                    if (!reset) {
                        if (receive) output = freeOutputs.removeFirst();
                        else if (pending == null) pending = queuedInputs.removeFirst();
                    }
                }
                if (reset) {
                    backend.flush();
                    synchronized (lock) { if (pending != null) { recycleInput(pending); pending = null; } }
                    activeGeneration = cycle;
                    receive = draining = ended = blocked = false;
                    first = true; skipped = 0;
                    continue;
                }
                if (output != null) {
                    int result;
                    try { result = backend.receive(output); }
                    catch (Throwable failure) { output.release(); throw failure; }
                    synchronized (lock) {
                        if (generation != cycle || released) { output.release(); continue; }
                        if (result == VideoDecoderBackend.FRAME) {
                            blocked = false;
                            if (outputStartUs != C.TIME_UNSET && output.timeUs < outputStartUs) {
                                skipped++; output.release();
                            } else {
                                output.format = format;
                                output.skippedOutputBufferCount = skipped; skipped = 0;
                                if (first) { output.addFlag(C.BUFFER_FLAG_FIRST_SAMPLE); first = false; }
                                queuedOutputs.add(output);
                            }
                        } else if (result == VideoDecoderBackend.END) {
                            output.addFlag(C.BUFFER_FLAG_END_OF_STREAM);
                            queuedOutputs.add(output);
                            receive = draining = false; ended = true;
                        } else {
                            output.release();
                            if (draining || blocked) throw new VideoDecoderException("FFmpeg made no progress while draining video");
                            receive = false;
                        }
                    }
                } else if (pending != null) {
                    boolean eos = pending.isEndOfStream();
                    if (pending.isEncrypted()) throw new VideoDecoderException("Encrypted video is unsupported by software decoder");
                    int size = pending.data == null ? 0 : pending.data.remaining();
                    int result = backend.send(pending.data, size, pending.timeUs, eos);
                    if (result == VideoDecoderBackend.AGAIN) { blocked = true; receive = true; }
                    else {
                        synchronized (lock) { recycleInput(pending); pending = null; }
                        blocked = false; receive = true; draining = eos;
                    }
                }
            }
        } catch (InterruptedException interrupted) {
            synchronized (lock) { if (!released) error = new VideoDecoderException("Video decoder interrupted", interrupted); }
        } catch (Throwable failure) {
            synchronized (lock) { error = failure instanceof VideoDecoderException
                    ? (VideoDecoderException) failure : new VideoDecoderException("Video software decoding failed", failure); }
        } finally {
            for (VideoDecoderOutputBuffer output : allOutputs) backend.releaseOutput(output);
            backend.release();
        }
    }
}
