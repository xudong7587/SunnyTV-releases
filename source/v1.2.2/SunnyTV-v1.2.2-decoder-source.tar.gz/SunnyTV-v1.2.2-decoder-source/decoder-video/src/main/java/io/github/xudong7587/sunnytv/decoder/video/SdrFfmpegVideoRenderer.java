/*
 * Based on NextLib FfmpegVideoRenderer, Copyright Anil Kumar Beesetti / NextLib contributors.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * See UPSTREAM.md for pinned sources, audit and modifications.
 */
package io.github.xudong7587.sunnytv.decoder.video;

import android.os.Handler;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.CryptoConfig;
import androidx.media3.decoder.Decoder;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import androidx.media3.exoplayer.RendererCapabilities;
import androidx.media3.exoplayer.video.DecoderVideoRenderer;
import androidx.media3.exoplayer.video.VideoRendererEventListener;
import java.util.Locale;

/** Software video extension for 8-bit SDR. Never performs HDR-to-SDR conversion. */
@UnstableApi
public final class SdrFfmpegVideoRenderer extends DecoderVideoRenderer {
    @Nullable private SdrVideoDecoder decoder;

    public SdrFfmpegVideoRenderer(long allowedJoiningTimeMs, @Nullable Handler handler,
            @Nullable VideoRendererEventListener listener, int maxDroppedFramesToNotify) {
        super(allowedJoiningTimeMs, handler, listener, maxDroppedFramesToNotify);
    }

    /** Capability only; does not load native code. The actual decoded frame is checked again in JNI. */
    public static boolean supportsInputFormat(Format format) {
        return unsupportedReason(format) == null;
    }

    /** Fixed, non-identifying diagnostic; null means the format passes the existing safety gates. */
    @Nullable public static String unsupportedReason(Format format) {
        if (!(MimeTypes.VIDEO_H264.equals(format.sampleMimeType)
                || MimeTypes.VIDEO_H265.equals(format.sampleMimeType)
                || MimeTypes.VIDEO_MP4V.equals(format.sampleMimeType))) return "视频编码不是 H.264、HEVC 或 MPEG-4 Part 2，或编码未知";
        if (format.width > 4096 || format.height > 4096) return "视频尺寸超过补充软解限制";
        if (format.pixelWidthHeightRatio != 1f) return "视频像素比例无法确认或不是方形像素";
        if (format.drmInitData != null || format.cryptoType != C.CRYPTO_TYPE_NONE) return "视频带有加密信息";
        if (format.rotationDegrees != 0 && format.rotationDegrees != Format.NO_VALUE) return "视频包含旋转信息";
        if (format.codecs != null) {
            String codecs = format.codecs.toLowerCase(Locale.US);
            if (codecs.contains("dvhe") || codecs.contains("dvh1") || codecs.contains("dva1")
                    || codecs.contains("dvav")) return "视频带有杜比视界标识";
        }
        ColorInfo color = format.colorInfo;
        if (color == null) return null;
        if (ColorInfo.isTransferHdr(color) || color.hdrStaticInfo != null) return "视频带有 HDR 色彩信息";
        if (color.colorSpace == C.COLOR_SPACE_BT2020) return "视频使用 BT.2020 广色域";
        if ((color.lumaBitdepth != Format.NO_VALUE && color.lumaBitdepth != 8)
                || (color.chromaBitdepth != Format.NO_VALUE && color.chromaBitdepth != 8)) return "视频位深不是 8 位";
        if (!(color.colorSpace == Format.NO_VALUE || color.colorSpace == C.COLOR_SPACE_BT709
                    || color.colorSpace == C.COLOR_SPACE_BT601)) return "视频色彩空间不在补充软解支持范围";
        if (!(color.colorTransfer == Format.NO_VALUE || color.colorTransfer == C.COLOR_TRANSFER_SDR
                    || color.colorTransfer == C.COLOR_TRANSFER_SRGB || color.colorTransfer == C.COLOR_TRANSFER_GAMMA_2_2))
            return "视频传递特性不在补充软解支持范围";
        return null;
    }

    @Override public String getName() { return "SunnySdrFfmpegVideoRenderer"; }

    @Override public int supportsFormat(Format format) {
        if (!MimeTypes.isVideo(format.sampleMimeType)) return C.FORMAT_UNSUPPORTED_TYPE;
        if (format.drmInitData != null || format.cryptoType != C.CRYPTO_TYPE_NONE)
            return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_DRM);
        if (!supportsInputFormat(format) || !VideoDecoderLibrary.isAvailable())
            return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_SUBTYPE);
        return RendererCapabilities.create(C.FORMAT_HANDLED, ADAPTIVE_NOT_SEAMLESS, TUNNELING_NOT_SUPPORTED);
    }

    @Override protected Decoder<DecoderInputBuffer, ? extends VideoDecoderOutputBuffer,
            ? extends VideoDecoderException> createDecoder(Format format, @Nullable CryptoConfig crypto)
            throws VideoDecoderException {
        if (crypto != null || !supportsInputFormat(format))
            throw new VideoDecoderException("补充视频软解仅支持无加密的8位SDR H.264、HEVC 或 MPEG-4 Part 2；HDR请使用平台解码器");
        decoder = new SdrVideoDecoder(format, new NativeVideoDecoder(format));
        return decoder;
    }

    @Override protected void renderOutputBufferToSurface(VideoDecoderOutputBuffer output, Surface surface)
            throws VideoDecoderException {
        SdrVideoDecoder current = decoder;
        if (current == null) throw new VideoDecoderException("Video decoder is not initialized");
        try { current.render(output, surface); } finally { output.release(); }
    }

    @Override protected void setDecoderOutputMode(@C.VideoOutputMode int mode) {
        // Only a native Surface is supported. No YUV GL path that could change HDR colors is exposed.
    }
}
