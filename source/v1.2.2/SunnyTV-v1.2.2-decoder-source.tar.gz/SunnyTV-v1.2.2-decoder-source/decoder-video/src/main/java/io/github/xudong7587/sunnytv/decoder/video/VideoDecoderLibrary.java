/* SPDX-License-Identifier: GPL-3.0-or-later */
package io.github.xudong7587.sunnytv.decoder.video;

import androidx.media3.common.util.UnstableApi;

/** Loads only the independently scoped video JNI library. No audio renderer is registered. */
@UnstableApi
public final class VideoDecoderLibrary {
    private static final boolean AVAILABLE;
    private static final String LOAD_STATUS;
    static {
        boolean loaded;
        String status;
        try { System.loadLibrary("sunnyVideoJNI"); loaded = true; status = "available"; }
        catch (UnsatisfiedLinkError error) { loaded = false; status = "native_link_error"; }
        catch (LinkageError error) { loaded = false; status = "native_linkage_error"; }
        catch (SecurityException error) { loaded = false; status = "native_load_blocked"; }
        AVAILABLE = loaded;
        LOAD_STATUS = status;
    }
    private VideoDecoderLibrary() {}
    public static boolean isAvailable() { return AVAILABLE; }
    /** Fixed tokens only: never expose native paths, exception messages or media information. */
    public static String getLoadStatus() { return LOAD_STATUS; }
    public static String getVersion() { return AVAILABLE ? NativeVideoDecoder.nativeVersion() : "unavailable"; }
}
