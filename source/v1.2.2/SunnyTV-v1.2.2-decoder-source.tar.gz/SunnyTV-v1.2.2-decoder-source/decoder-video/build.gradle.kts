plugins { id("com.android.library") }
android {
    namespace = "io.github.xudong7587.sunnytv.decoder.video"
    compileSdk = 35
    ndkVersion = "26.1.10909125"
    defaultConfig {
        minSdk = 24
        consumerProguardFiles("consumer-rules.pro")
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64") }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    // AGP 8.9.2 misses quoted CMake .so fragments when the workspace path contains spaces.
    // Normal paths already package IMPORTED runtimes; avoid adding the same libraries twice.
    if (rootProject.projectDir.absolutePath.contains(' ')) {
        sourceSets.getByName("main").jniLibs.srcDir("src/main/cpp/vendor/lib")
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    testOptions { unitTests.isReturnDefaultValues = true }
}
dependencies {
    api("androidx.media3:media3-exoplayer:1.9.4")
    implementation("androidx.annotation:annotation:1.9.1")
    testImplementation("junit:junit:4.13.2")
}
