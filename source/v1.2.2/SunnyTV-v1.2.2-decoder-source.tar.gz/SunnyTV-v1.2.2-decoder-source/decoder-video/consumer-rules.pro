# JNI accesses the public Media3 output fields and methods below.
-keep class io.github.xudong7587.sunnytv.decoder.video.NativeVideoDecoder { *; }
-keepclassmembers class androidx.media3.decoder.VideoDecoderOutputBuffer { *; }
