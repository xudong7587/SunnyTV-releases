#!/bin/bash
# Build the shared FFmpeg runtime used by both SunnyTV decoder adapters.
# Source is a clean checkout of the audited n6.0.1 commit, kept outside the repository.
# Outputs go to a staging directory; this script never overwrites vendor inputs.
set -euo pipefail

source_dir="${1:?pass the FFmpeg n6.0.1 checkout}"
output_dir="${2:?pass an output staging directory}"
# NASM is required for x86_64 accelerated routines. ARM assembly is built by
# the Android NDK clang toolchain.
command -v nasm >/dev/null || { echo 'NASM is required on PATH for x86_64 SIMD' >&2; exit 1; }
ndk_dir="${ANDROID_HOME:?set ANDROID_HOME}/ndk/26.1.10909125"
tool_dir="$ndk_dir/toolchains/llvm/prebuilt/darwin-x86_64/bin"
expected_commit=c41ff724ede7da657762d61097e26fac296c53bf
[[ "$(git -C "$source_dir" rev-parse HEAD)" == "$expected_commit" ]]
[[ -z "$(git -C "$source_dir" status --porcelain)" ]]
mkdir -p "$output_dir"
output_dir="$(cd "$output_dir" && pwd)"
source_dir="$(cd "$source_dir" && pwd)"

# Native vp8/vp9 replace the previous third-party libvpx implementation; no
# second copy of FFmpeg or external libvpx is bundled. Other enabled decoders
# match the previous build, with MPEG-4 Part 2 added for video/mp4v-es.
decoders=(vorbis opus flac alac pcm_mulaw pcm_alaw mp3 amrnb amrwb aac ac3 eac3 dca mlp truehd h264 hevc mpeg2video mpegvideo vp8 vp9 mpeg4)
decoder_options=()
for decoder in "${decoders[@]}"; do decoder_options+=("--enable-decoder=$decoder"); done

for spec in 'armeabi-v7a arm armv7-a armv7a-linux-androideabi' \
            'arm64-v8a aarch64 armv8-a aarch64-linux-android' \
            'x86 x86 i686 i686-linux-android' \
            'x86_64 x86_64 x86-64 x86_64-linux-android'; do
    read -r abi arch cpu target <<< "$spec"
    if [[ -n "${SUNNYTV_FFMPEG_ABI:-}" && "$abi" != "$SUNNYTV_FFMPEG_ABI" ]]; then continue; fi
    # FFmpeg 6.0's 32-bit x86 assembler (including inline assembly) emits
    # relocations Android rejects in shared libraries. ARM and x86_64 retain asm.
    arch_options=(--enable-asm)
    if [[ "$abi" == x86 ]]; then arch_options=(--disable-asm); fi
    build_dir="$output_dir/build/$abi"
    install_dir="$output_dir/install/$abi"
    mkdir -p "$build_dir" "$install_dir"
    (
        cd "$build_dir"
        "$source_dir/configure" --prefix="$install_dir" --libdir="$install_dir/lib" \
            --target-os=android --arch="$arch" --cpu="$cpu" --enable-cross-compile \
            --cc="$tool_dir/${target}24-clang" --cxx="$tool_dir/${target}24-clang++" \
            --ar="$tool_dir/llvm-ar" --nm="$tool_dir/llvm-nm" \
            --ranlib="$tool_dir/llvm-ranlib" --strip="$tool_dir/llvm-strip" \
            --enable-shared --enable-pic --disable-static --disable-programs --disable-doc \
            --disable-everything --disable-avdevice --disable-avformat --disable-postproc \
            --disable-avfilter --disable-vulkan --disable-v4l2-m2m \
            --disable-symver --enable-version3 --enable-swresample --enable-swscale \
            --extra-cflags='-O3 -fPIC' --extra-ldflags='-Wl,-z,max-page-size=16384' \
            "${arch_options[@]}" "${decoder_options[@]}"
        make -j"${SUNNYTV_FFMPEG_JOBS:-8}"
        make install-libs
    )
done
